const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_store_01";
const BOB_UID = "bob_store_02";

const [emulatorHost, emulatorPortStr] = (
  process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085"
).split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

function pastDate(msOffset = 2000) {
  return new Date(Date.now() - msOffset);
}

function sampleProductPayload(userId, now = pastDate()) {
  return {
    userId,
    name: "أرز بسمتي هندي",
    barcode: "6221000112233",
    category: "بقالة",
    trackingType: "WEIGHT",
    baseUnitName: "كيلو",
    stockInBaseUnits: 50.0,
    lowStockThreshold: 5.0,
    costPrice: 55.0,
    units: [
      {
        unitName: "كيلو",
        unitType: "KG",
        conversionFactor: 1.0,
        price: 70.0,
        allowDecimal: true,
        barcode: "6221000112233",
      },
      {
        unitName: "شيكارة 25 كيلو",
        unitType: "CARTON",
        conversionFactor: 25.0,
        price: 1650.0,
        allowDecimal: false,
        barcode: "",
      },
    ],
    createdAt: now,
    updatedAt: now,
  };
}

function sampleInvoicePayload(userId, now = pastDate()) {
  return {
    userId,
    invoiceNumber: "INV-2026-0001",
    customerName: "عميل نقدي",
    paymentMethod: "CASH",
    status: "COMPLETED",
    items: [
      {
        productId: "prod_1",
        productName: "أرز بسمتي هندي",
        unitName: "كيلو",
        unitType: "KG",
        conversionFactor: 1.0,
        quantity: 2.5,
        unitPrice: 70.0,
        lineTotal: 175.0,
      },
    ],
    subtotal: 175.0,
    discountAmount: 5.0,
    taxAmount: 0.0,
    totalAmount: 170.0,
    paidAmount: 200.0,
    changeAmount: 30.0,
    itemCount: 1,
    createdAt: now,
    updatedAt: now,
  };
}

test("Unauthenticated user: denied across products, invoices, and storeSettings", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(
    unauthDb.collection("users").doc(ALICE_UID).collection("products").get()
  );
  await assertFails(
    unauthDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("products")
      .doc("p1")
      .set(sampleProductPayload(ALICE_UID))
  );
  await assertFails(
    unauthDb.collection("users").doc(ALICE_UID).collection("invoices").get()
  );
  await assertFails(
    unauthDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("storeSettings")
      .doc("config")
      .get()
  );
});

test("Products: owner create, list, partial stock deduction, full edit, and delete succeed", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const productsCol = aliceDb
    .collection("users")
    .doc(ALICE_UID)
    .collection("products");

  await assertSucceeds(productsCol.doc("prod_1").set(sampleProductPayload(ALICE_UID)));
  await assertSucceeds(productsCol.get());

  // Stock deduction action
  await assertSucceeds(
    productsCol.doc("prod_1").update({
      stockInBaseUnits: 47.5,
      updatedAt: pastDate(500),
    })
  );

  // Full catalog edit action
  await assertSucceeds(
    productsCol.doc("prod_1").update({
      name: "أرز بسمتي فاخر",
      barcode: "6221000112299",
      category: "حبوب",
      trackingType: "WEIGHT",
      baseUnitName: "كيلو",
      stockInBaseUnits: 60.0,
      lowStockThreshold: 10.0,
      costPrice: 58.0,
      units: [
        {
          unitName: "كيلو",
          unitType: "KG",
          conversionFactor: 1.0,
          price: 75.0,
          allowDecimal: true,
          barcode: "",
        },
      ],
      updatedAt: pastDate(200),
    })
  );

  await assertSucceeds(productsCol.doc("prod_1").delete());
});

test("Products: reject cross-user access, ghost fields, @DocumentId id field, and future timestamps", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();

  await assertSucceeds(
    aliceDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("products")
      .doc("prod_1")
      .set(sampleProductPayload(ALICE_UID))
  );

  // Bob cannot read, list, update, or delete Alice's products
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).collection("products").get()
  );
  await assertFails(
    bobDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("products")
      .doc("prod_1")
      .update({ stockInBaseUnits: 0.0, updatedAt: pastDate(100) })
  );

  // Ghost field & id field rejected
  await assertFails(
    aliceDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("products")
      .doc("prod_ghost")
      .set({
        ...sampleProductPayload(ALICE_UID),
        id: "prod_ghost",
      })
  );

  // Future timestamp rejected
  await assertFails(
    aliceDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("products")
      .doc("prod_future")
      .set(sampleProductPayload(ALICE_UID, new Date(Date.now() + 60000)))
  );

  // Immutable createdAt cannot be modified
  await assertFails(
    aliceDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("products")
      .doc("prod_1")
      .update({
        createdAt: pastDate(100),
        updatedAt: pastDate(100),
      })
  );
});

test("Invoices: owner create, list, refund transition succeed; double-refund and delete fail", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const invoicesCol = aliceDb
    .collection("users")
    .doc(ALICE_UID)
    .collection("invoices");

  await assertSucceeds(
    invoicesCol.doc("inv_1").set(sampleInvoicePayload(ALICE_UID))
  );
  await assertSucceeds(invoicesCol.get());

  // Refund transition allowed once
  await assertSucceeds(
    invoicesCol.doc("inv_1").update({
      status: "REFUNDED",
      updatedAt: pastDate(400),
    })
  );

  // Terminal state lock: second update rejected
  await assertFails(
    invoicesCol.doc("inv_1").update({
      status: "COMPLETED",
      updatedAt: pastDate(100),
    })
  );

  // Delete always denied for audit integrity
  await assertFails(invoicesCol.doc("inv_1").delete());
});

test("StoreSettings: owner create config doc and update allowed fields", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const configRef = aliceDb
    .collection("users")
    .doc(ALICE_UID)
    .collection("storeSettings")
    .doc("config");

  const now = pastDate();
  await assertSucceeds(
    configRef.set({
      userId: ALICE_UID,
      storeName: "سوبر ماركت النور",
      currencySymbol: "ج.م",
      taxRatePercent: 14.0,
      receiptFooter: "شكراً لزيارتكم",
      createdAt: now,
      updatedAt: now,
    })
  );

  await assertSucceeds(
    configRef.update({
      storeName: "أسواق النور الحديثة",
      taxRatePercent: 15.0,
      updatedAt: pastDate(200),
    })
  );

  // Wrong document ID rejected on create
  await assertFails(
    aliceDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("storeSettings")
      .doc("other")
      .set({
        userId: ALICE_UID,
        storeName: "اختبار",
        currencySymbol: "ج.م",
        taxRatePercent: 0.0,
        receiptFooter: "",
        createdAt: now,
        updatedAt: now,
      })
  );
});
