package com.example

import com.example.data.importer.FileProductImporter
import com.example.data.model.CartItem
import com.example.data.model.Product
import com.example.data.model.ProductUnit
import com.example.data.model.TrackingType
import com.example.data.model.UnitType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class FileProductImporterTest {

    @Test
    fun `csv sample template parses multi-unit carton and weight products`() {
        val csv = FileProductImporter.buildSampleCsvTemplate()
        val result = FileProductImporter.parseCsvOrText("products.csv", csv.toByteArray(Charsets.UTF_8))

        assertEquals(5, result.drafts.size)

        val sugar = result.drafts[0]
        assertEquals("سكر أبيض ناعم", sugar.name)
        assertEquals(TrackingType.WEIGHT, sugar.trackingType)
        assertEquals("كيلو", sugar.baseUnitName)
        assertEquals(38.0, sugar.units.first().price, 0.01)
        assertTrue(sugar.units.any { it.unitType == UnitType.GRAM.name })

        val soda = result.drafts[1]
        assertEquals("مياه غازية 330 مل", soda.name)
        assertEquals(TrackingType.COUNT, soda.trackingType)
        assertEquals(2, soda.units.size)
        assertEquals(15.0, soda.units[0].price, 0.01)
        assertEquals(340.0, soda.units[1].price, 0.01)
        assertEquals(24.0, soda.units[1].conversionFactor, 0.01)
    }

    @Test
    fun `arabic digits and semicolon csv rows merge multiple units for same product`() {
        val csv = """
            الاسم;الوحدة;السعر;الكمية
            شاي ليبتون;قطعة;١٠;١٠٠
            شاي ليبتون;كرتونة;٢٢٠;١٠
        """.trimIndent()

        val result = FileProductImporter.parseCsvOrText("items.csv", csv.toByteArray(Charsets.UTF_8))
        assertEquals(1, result.drafts.size)
        val tea = result.drafts.first()
        assertEquals("شاي ليبتون", tea.name)
        assertEquals(2, tea.units.size)
        assertEquals(10.0, tea.units[0].price, 0.01)
        assertEquals(220.0, tea.units[1].price, 0.01)
        assertEquals(12.0, tea.units[1].conversionFactor, 0.01)
    }

    @Test
    fun `multi-unit cart calculation computes weight and carton base unit deductions accurately`() {
        val rice = Product(
            id = "p1",
            name = "أرز بسمتي",
            trackingType = TrackingType.WEIGHT.name,
            baseUnitName = "كيلو",
            stockInBaseUnits = 50.0,
        )
        val kgUnit = ProductUnit("كيلو", UnitType.KG.name, 1.0, 70.0, true)
        val sackUnit = ProductUnit("شيكارة 25 كيلو", UnitType.CARTON.name, 25.0, 1650.0, false)

        val item1 = CartItem("p1__kg", rice, kgUnit, 1.5)
        val item2 = CartItem("p1__sack", rice, sackUnit, 1.0)

        assertEquals(105.0, item1.lineTotal, 0.01)
        assertEquals(1650.0, item2.lineTotal, 0.01)
        assertEquals(26.5, item1.baseUnitsConsumed + item2.baseUnitsConsumed, 0.01)
    }
}
