package com.example.ui.viewmodel

import android.content.Context
import android.net.Uri
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.firebase.PosRepository
import com.example.data.importer.FileProductImporter
import com.example.data.model.CartItem
import com.example.data.model.ImportedProductDraft
import com.example.data.model.Invoice
import com.example.data.model.PaymentMethod
import com.example.data.model.Product
import com.example.data.model.ProductUnit
import com.example.data.model.StoreSettings
import com.example.data.model.TrackingType
import com.example.data.model.UiState
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class CartSummary(
    val subtotal: Double = 0.0,
    val discountAmount: Double = 0.0,
    val taxAmount: Double = 0.0,
    val totalAmount: Double = 0.0,
    val paidAmount: Double = 0.0,
    val changeAmount: Double = 0.0,
    val totalItemLines: Int = 0,
)

data class ImportUiState(
    val fileName: String = "",
    val fileTypeLabel: String = "",
    val drafts: List<ImportedProductDraft> = emptyList(),
    val isParsing: Boolean = false,
    val isImporting: Boolean = false,
    val errorMessage: String? = null,
)

class CashierViewModel(
    private val repository: PosRepository,
    private val currentUserId: String,
) : ViewModel() {

    val productsState: StateFlow<UiState<List<Product>>> = repository.observeProducts(currentUserId)
        .map<List<Product>, UiState<List<Product>>> { UiState.Success(it) }
        .catch { error ->
            val firestoreError = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (firestoreError == null && error is CancellationException) throw error
            val rootError = firestoreError ?: error
            Log.w(TAG, "Error observing products", rootError)
            emit(UiState.Error(rootError.localizedMessage ?: "تعذر تحميل قائمة الأصناف"))
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = UiState.Loading
        )

    val invoicesState: StateFlow<UiState<List<Invoice>>> = repository.observeInvoices(currentUserId)
        .map<List<Invoice>, UiState<List<Invoice>>> { UiState.Success(it) }
        .catch { error ->
            val firestoreError = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (firestoreError == null && error is CancellationException) throw error
            val rootError = firestoreError ?: error
            Log.w(TAG, "Error observing invoices", rootError)
            emit(UiState.Error(rootError.localizedMessage ?: "تعذر تحميل الفواتير"))
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = UiState.Loading
        )

    val settingsState: StateFlow<StoreSettings> = repository.observeStoreSettings(currentUserId)
        .catch { error ->
            val firestoreError = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (firestoreError == null && error is CancellationException) throw error
            Log.w(TAG, "Error observing settings", firestoreError ?: error)
            emit(StoreSettings(userId = currentUserId))
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = StoreSettings(userId = currentUserId)
        )

    private val _cartItems = MutableStateFlow<List<CartItem>>(emptyList())
    val cartItems: StateFlow<List<CartItem>> = _cartItems.asStateFlow()

    private val _discountInput = MutableStateFlow("")
    val discountInput: StateFlow<String> = _discountInput.asStateFlow()

    private val _discountIsPercent = MutableStateFlow(false)
    val discountIsPercent: StateFlow<Boolean> = _discountIsPercent.asStateFlow()

    private val _customerName = MutableStateFlow("")
    val customerName: StateFlow<String> = _customerName.asStateFlow()

    private val _paymentMethod = MutableStateFlow(PaymentMethod.CASH)
    val paymentMethod: StateFlow<PaymentMethod> = _paymentMethod.asStateFlow()

    private val _paidAmountInput = MutableStateFlow("")
    val paidAmountInput: StateFlow<String> = _paidAmountInput.asStateFlow()

    private val _isCheckingOut = MutableStateFlow(false)
    val isCheckingOut: StateFlow<Boolean> = _isCheckingOut.asStateFlow()

    private val _activeReceiptInvoice = MutableStateFlow<Invoice?>(null)
    val activeReceiptInvoice: StateFlow<Invoice?> = _activeReceiptInvoice.asStateFlow()

    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

    private val _importState = MutableStateFlow(ImportUiState())
    val importState: StateFlow<ImportUiState> = _importState.asStateFlow()

    val cartSummary: StateFlow<CartSummary> = combine(
        _cartItems,
        _discountInput,
        _discountIsPercent,
        _paidAmountInput,
        settingsState,
    ) { items, discStr, isPct, paidStr, settings ->
        val subtotal = items.sumOf { it.lineTotal }
        val rawDisc = discStr.toDoubleOrNull() ?: 0.0
        val discountAmount = if (isPct) {
            (subtotal * (rawDisc.coerceIn(0.0, 100.0) / 100.0))
        } else {
            rawDisc.coerceIn(0.0, subtotal)
        }
        val taxable = (subtotal - discountAmount).coerceAtLeast(0.0)
        val taxAmount = taxable * (settings.taxRatePercent.coerceIn(0.0, 100.0) / 100.0)
        val total = (taxable + taxAmount).coerceAtLeast(0.0)
        val paid = paidStr.toDoubleOrNull() ?: total
        val change = (paid - total).coerceAtLeast(0.0)
        CartSummary(
            subtotal = subtotal,
            discountAmount = discountAmount,
            taxAmount = taxAmount,
            totalAmount = total,
            paidAmount = paid,
            changeAmount = change,
            totalItemLines = items.size,
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
        initialValue = CartSummary()
    )

    fun addToCart(product: Product, unit: ProductUnit, quantity: Double = 1.0) {
        if (quantity <= 0.0) return
        val key = "${product.id}__${unit.unitName}"
        _cartItems.update { current ->
            val existingIdx = current.indexOfFirst { it.key == key }
            if (existingIdx >= 0) {
                current.toMutableList().also { list ->
                    val old = list[existingIdx]
                    list[existingIdx] = old.copy(quantity = old.quantity + quantity)
                }
            } else {
                current + CartItem(key = key, product = product, unit = unit, quantity = quantity)
            }
        }
    }

    fun updateCartItemQuantity(key: String, newQuantity: Double) {
        _cartItems.update { current ->
            if (newQuantity <= 0.0) {
                current.filterNot { it.key == key }
            } else {
                current.map { item ->
                    if (item.key == key) item.copy(quantity = newQuantity) else item
                }
            }
        }
    }

    fun switchCartItemUnit(key: String, newUnit: ProductUnit) {
        _cartItems.update { current ->
            val target = current.firstOrNull { it.key == key } ?: return@update current
            val newKey = "${target.product.id}__${newUnit.unitName}"
            if (newKey == key) return@update current
            val filtered = current.filterNot { it.key == key }
            val existingSameUnit = filtered.indexOfFirst { it.key == newKey }
            if (existingSameUnit >= 0) {
                filtered.toMutableList().also { list ->
                    val old = list[existingSameUnit]
                    list[existingSameUnit] = old.copy(quantity = old.quantity + target.quantity)
                }
            } else {
                filtered + target.copy(key = newKey, unit = newUnit)
            }
        }
    }

    fun clearCart() {
        _cartItems.value = emptyList()
        _discountInput.value = ""
        _customerName.value = ""
        _paidAmountInput.value = ""
    }

    fun setDiscountInput(value: String) {
        _discountInput.value = value
    }

    fun setDiscountIsPercent(isPercent: Boolean) {
        _discountIsPercent.value = isPercent
    }

    fun setCustomerName(name: String) {
        _customerName.value = name
    }

    fun setPaymentMethod(method: PaymentMethod) {
        _paymentMethod.value = method
    }

    fun setPaidAmountInput(value: String) {
        _paidAmountInput.value = value
    }

    fun completeCheckout() {
        val items = _cartItems.value
        if (items.isEmpty() || _isCheckingOut.value) return
        val summary = cartSummary.value
        val settings = settingsState.value
        val currentInvoices = (invoicesState.value as? UiState.Success)?.data?.size ?: 0

        _isCheckingOut.value = true
        viewModelScope.launch {
            val result = repository.checkoutSale(
                userId = currentUserId,
                cartItems = items,
                customerName = _customerName.value,
                paymentMethod = _paymentMethod.value,
                discountAmount = summary.discountAmount,
                taxRatePercent = settings.taxRatePercent,
                paidAmount = summary.paidAmount,
                currentInvoiceCount = currentInvoices,
            )
            _isCheckingOut.value = false
            result.onSuccess { invoice ->
                clearCart()
                _activeReceiptInvoice.value = invoice
                _snackbarMessage.value = "تم إصدار الفاتورة ${invoice.invoiceNumber} بنجاح"
            }.onFailure { err ->
                _snackbarMessage.value = err.localizedMessage ?: "تعذر إتمام عملية البيع"
            }
        }
    }

    fun showReceipt(invoice: Invoice?) {
        _activeReceiptInvoice.value = invoice
    }

    fun saveProduct(product: Product, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            val result = repository.upsertProduct(currentUserId, product)
            result.onSuccess {
                _snackbarMessage.value = if (product.id.isBlank()) "تمت إضافة الصنف بنجاح" else "تم تحديث بيانات الصنف"
                onSuccess()
            }.onFailure { err ->
                _snackbarMessage.value = err.localizedMessage ?: "تعذر حفظ الصنف"
            }
        }
    }

    fun deleteProduct(productId: String) {
        viewModelScope.launch {
            val result = repository.deleteProduct(currentUserId, productId)
            result.onSuccess {
                _snackbarMessage.value = "تم حذف الصنف"
            }.onFailure { err ->
                _snackbarMessage.value = err.localizedMessage ?: "تعذر حذف الصنف"
            }
        }
    }

    fun saveSettings(settings: StoreSettings, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            val result = repository.saveStoreSettings(currentUserId, settings)
            result.onSuccess {
                _snackbarMessage.value = "تم حفظ إعدادات المتجر"
                onSuccess()
            }.onFailure { err ->
                _snackbarMessage.value = err.localizedMessage ?: "تعذر حفظ الإعدادات"
            }
        }
    }

    fun refundInvoice(invoice: Invoice) {
        val currentProducts = (productsState.value as? UiState.Success)?.data ?: emptyList()
        viewModelScope.launch {
            val result = repository.refundInvoice(currentUserId, invoice, currentProducts)
            result.onSuccess {
                _activeReceiptInvoice.value = null
                _snackbarMessage.value = "تم استرجاع الفاتورة وإعادة الكميات للمخزون"
            }.onFailure { err ->
                _snackbarMessage.value = err.localizedMessage ?: "تعذر استرجاع الفاتورة"
            }
        }
    }

    fun seedSampleCatalog() {
        viewModelScope.launch {
            val result = repository.seedSampleCatalog(currentUserId)
            result.onSuccess {
                _snackbarMessage.value = "تمت إضافة أصناف نموذجية متعددة الوحدات"
            }.onFailure { err ->
                _snackbarMessage.value = err.localizedMessage ?: "تعذر إضافة الأصناف النموذجية"
            }
        }
    }

    // --- PDF & Excel Import Actions ---
    fun parseImportFile(context: Context, uri: Uri) {
        _importState.update { it.copy(isParsing = true, errorMessage = null) }
        viewModelScope.launch {
            val result = FileProductImporter.parseUri(context, uri)
            result.onSuccess { parsed ->
                _importState.value = ImportUiState(
                    fileName = parsed.fileName,
                    fileTypeLabel = parsed.fileTypeLabel,
                    drafts = parsed.drafts,
                    isParsing = false,
                    errorMessage = if (parsed.drafts.isEmpty()) {
                        "لم يتم العثور على صفوف أصناف صالحة داخل الملف (${parsed.rawLinesCount} سطر مقروء)"
                    } else null,
                )
            }.onFailure { err ->
                _importState.update {
                    it.copy(
                        isParsing = false,
                        errorMessage = err.localizedMessage ?: "تعذر قراءة الملف"
                    )
                }
            }
        }
    }

    fun toggleDraftSelection(localId: String) {
        _importState.update { state ->
            state.copy(
                drafts = state.drafts.map { draft ->
                    if (draft.localId == localId) draft.copy(selected = !draft.selected) else draft
                }
            )
        }
    }

    fun selectAllDrafts(selected: Boolean) {
        _importState.update { state ->
            state.copy(drafts = state.drafts.map { it.copy(selected = selected) })
        }
    }

    fun updateDraft(updated: ImportedProductDraft) {
        _importState.update { state ->
            state.copy(
                drafts = state.drafts.map { if (it.localId == updated.localId) updated else it }
            )
        }
    }

    fun addManualDraftUnit(localId: String, unit: ProductUnit) {
        _importState.update { state ->
            state.copy(
                drafts = state.drafts.map { draft ->
                    if (draft.localId == localId) {
                        draft.copy(units = (draft.units + unit).take(10))
                    } else draft
                }
            )
        }
    }

    fun updateDraftTrackingType(localId: String, trackingType: TrackingType) {
        _importState.update { state ->
            state.copy(
                drafts = state.drafts.map { draft ->
                    if (draft.localId == localId) {
                        val defaultBase = if (trackingType == TrackingType.WEIGHT) "كيلو" else "قطعة"
                        draft.copy(trackingType = trackingType, baseUnitName = defaultBase)
                    } else draft
                }
            )
        }
    }

    fun clearImportDrafts() {
        _importState.value = ImportUiState()
    }

    fun commitImport() {
        val drafts = _importState.value.drafts
        if (drafts.none { it.selected } || _importState.value.isImporting) return

        _importState.update { it.copy(isImporting = true, errorMessage = null) }
        viewModelScope.launch {
            val result = repository.importProductsBatch(currentUserId, drafts)
            result.onSuccess { count ->
                _importState.value = ImportUiState()
                _snackbarMessage.value = "تم استيراد $count صنف إلى المخزون بنجاح"
            }.onFailure { err ->
                _importState.update {
                    it.copy(
                        isImporting = false,
                        errorMessage = err.localizedMessage ?: "تعذر حفظ الأصناف المستوردة"
                    )
                }
            }
        }
    }

    fun consumeSnackbar() {
        _snackbarMessage.value = null
    }

    private companion object {
        const val TAG = "CashierVM"
        const val STOP_TIMEOUT_MILLIS = 5000L
    }
}
