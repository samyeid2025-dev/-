package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.Invoice
import com.example.data.model.InvoiceStatus
import com.example.data.model.StoreSettings
import com.example.data.model.formatMoney
import com.example.data.model.formatQuantity
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.SuccessGreen
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ReceiptDialog(
    invoice: Invoice,
    settings: StoreSettings,
    onDismiss: () -> Unit,
    onRefund: ((Invoice) -> Unit)? = null,
) {
    val context = LocalContext.current
    val currency = settings.currencySymbol
    val dateStr = SimpleDateFormat("yyyy/MM/dd  HH:mm", Locale.US)
        .format(invoice.createdAt?.toDate() ?: Date())

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surfaceContainerLowest,
            tonalElevation = 6.dp,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 24.dp),
        ) {
            Column(
                modifier = Modifier
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Icon(
                            imageVector = Icons.Filled.CheckCircle,
                            contentDescription = null,
                            tint = if (invoice.resolvedStatus() == InvoiceStatus.COMPLETED) {
                                SuccessGreen
                            } else {
                                MaterialTheme.colorScheme.error
                            },
                        )
                        Text(
                            text = if (invoice.resolvedStatus() == InvoiceStatus.COMPLETED) {
                                "إيصال فاتورة مبيعات"
                            } else {
                                "فاتورة مرتجعة"
                            },
                            style = MaterialTheme.typography.titleLarge,
                        )
                    }
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.testTag("close_receipt_button"),
                    ) {
                        Icon(Icons.Filled.Close, contentDescription = "إغلاق الإيصال")
                    }
                }

                // Store Receipt Card
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            MaterialTheme.colorScheme.surfaceContainer,
                            RoundedCornerShape(16.dp),
                        )
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text(
                        text = settings.storeName,
                        style = MaterialTheme.typography.titleLarge,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Text(
                        text = invoice.invoiceNumber,
                        fontFamily = JetBrainsMonoFontFamily,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Text(
                        text = dateStr,
                        fontFamily = JetBrainsMonoFontFamily,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth(),
                    )

                    if (invoice.customerName.isNotBlank()) {
                        Text(
                            text = "العميل: ${invoice.customerName}",
                            style = MaterialTheme.typography.bodyMedium,
                        )
                    }
                    Text(
                        text = "طريقة الدفع: ${invoice.resolvedPaymentMethod().labelAr}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                    invoice.items.forEach { item ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top,
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = item.productName,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold,
                                )
                                Text(
                                    text = "${formatQuantity(item.quantity)} ${item.unitName} × ${formatMoney(item.unitPrice, currency)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                            Text(
                                text = formatMoney(item.lineTotal, currency),
                                fontFamily = JetBrainsMonoFontFamily,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                            )
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                    ReceiptSummaryRow("المجموع الفرعي", formatMoney(invoice.subtotal, currency))
                    if (invoice.discountAmount > 0.0) {
                        ReceiptSummaryRow("الخصم", "- ${formatMoney(invoice.discountAmount, currency)}")
                    }
                    if (invoice.taxAmount > 0.0) {
                        ReceiptSummaryRow("الضريبة", formatMoney(invoice.taxAmount, currency))
                    }
                    ReceiptSummaryRow(
                        label = "الإجمالي النهائي",
                        value = formatMoney(invoice.totalAmount, currency),
                        highlight = true,
                    )
                    ReceiptSummaryRow("المدفوع", formatMoney(invoice.paidAmount, currency))
                    if (invoice.changeAmount > 0.0) {
                        ReceiptSummaryRow("المتبقي للعميل", formatMoney(invoice.changeAmount, currency))
                    }

                    if (settings.receiptFooter.isNotBlank()) {
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = settings.receiptFooter,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Button(
                        onClick = {
                            val shareText = buildReceiptText(invoice, settings, dateStr)
                            val intent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_SUBJECT, "فاتورة ${invoice.invoiceNumber}")
                                putExtra(Intent.EXTRA_TEXT, shareText)
                            }
                            context.startActivity(Intent.createChooser(intent, "مشاركة الفاتورة"))
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("share_receipt_button"),
                    ) {
                        Icon(Icons.Filled.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("مشاركة")
                    }

                    if (onRefund != null && invoice.resolvedStatus() == InvoiceStatus.COMPLETED) {
                        OutlinedButton(
                            onClick = { onRefund(invoice) },
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = MaterialTheme.colorScheme.error
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("refund_invoice_button"),
                        ) {
                            Icon(Icons.Filled.Replay, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("استرجاع")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ReceiptSummaryRow(
    label: String,
    value: String,
    highlight: Boolean = false,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(
            text = label,
            style = if (highlight) MaterialTheme.typography.titleMedium else MaterialTheme.typography.bodyMedium,
            fontWeight = if (highlight) FontWeight.Bold else FontWeight.Normal,
        )
        Text(
            text = value,
            fontFamily = JetBrainsMonoFontFamily,
            style = if (highlight) MaterialTheme.typography.titleMedium else MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Bold,
            color = if (highlight) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
        )
    }
}

private fun buildReceiptText(invoice: Invoice, settings: StoreSettings, dateStr: String): String {
    val currency = settings.currencySymbol
    return buildString {
        appendLine("=== ${settings.storeName} ===")
        appendLine("فاتورة رقم: ${invoice.invoiceNumber}")
        appendLine("التاريخ: $dateStr")
        if (invoice.customerName.isNotBlank()) {
            appendLine("العميل: ${invoice.customerName}")
        }
        appendLine("طريقة الدفع: ${invoice.resolvedPaymentMethod().labelAr}")
        appendLine("------------------------------")
        invoice.items.forEach { item ->
            appendLine("${item.productName}")
            appendLine("  ${formatQuantity(item.quantity)} ${item.unitName} × ${formatMoney(item.unitPrice, currency)} = ${formatMoney(item.lineTotal, currency)}")
        }
        appendLine("------------------------------")
        appendLine("المجموع الفرعي: ${formatMoney(invoice.subtotal, currency)}")
        if (invoice.discountAmount > 0.0) {
            appendLine("الخصم: ${formatMoney(invoice.discountAmount, currency)}")
        }
        if (invoice.taxAmount > 0.0) {
            appendLine("الضريبة: ${formatMoney(invoice.taxAmount, currency)}")
        }
        appendLine("الإجمالي: ${formatMoney(invoice.totalAmount, currency)}")
        appendLine("المدفوع: ${formatMoney(invoice.paidAmount, currency)}")
        if (invoice.changeAmount > 0.0) {
            appendLine("الباقي: ${formatMoney(invoice.changeAmount, currency)}")
        }
        if (settings.receiptFooter.isNotBlank()) {
            appendLine()
            appendLine(settings.receiptFooter)
        }
    }
}
