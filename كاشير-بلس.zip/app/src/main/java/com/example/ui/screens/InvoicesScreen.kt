package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.Invoice
import com.example.data.model.InvoiceStatus
import com.example.data.model.Product
import com.example.data.model.StoreSettings
import com.example.data.model.UiState
import com.example.data.model.formatMoney
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.WarningAmber
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@Composable
fun InvoicesScreen(
    invoicesState: UiState<List<Invoice>>,
    productsState: UiState<List<Product>>,
    settings: StoreSettings,
    onSelectInvoice: (Invoice) -> Unit,
) {
    var searchQuery by remember { mutableStateOf("") }
    var statusFilter by remember { mutableStateOf<InvoiceStatus?>(null) }

    val products = (productsState as? UiState.Success)?.data ?: emptyList()
    val lowStockCount = remember(products) { products.count { it.isLowStockFlag() } }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        when (invoicesState) {
            is UiState.Loading -> {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            }

            is UiState.Error -> {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(invoicesState.message, color = MaterialTheme.colorScheme.error)
                }
            }

            is UiState.Success -> {
                val invoices = invoicesState.data
                val todayStats = remember(invoices) {
                    val cal = Calendar.getInstance()
                    cal.set(Calendar.HOUR_OF_DAY, 0)
                    cal.set(Calendar.MINUTE, 0)
                    cal.set(Calendar.SECOND, 0)
                    cal.set(Calendar.MILLISECOND, 0)
                    val startOfDay = cal.timeInMillis

                    val todayCompleted = invoices.filter { inv ->
                        val ts = inv.createdAt?.toDate()?.time ?: 0L
                        ts >= startOfDay && inv.resolvedStatus() == InvoiceStatus.COMPLETED
                    }
                    val totalSales = todayCompleted.sumOf { it.totalAmount }
                    val count = todayCompleted.size
                    val avg = if (count > 0) totalSales / count else 0.0
                    Triple(totalSales, count, avg)
                }

                // Daily KPI Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    KpiSummaryCard(
                        label = "مبيعات اليوم",
                        value = formatMoney(todayStats.first, settings.currencySymbol),
                        accent = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.weight(1.2f),
                    )
                    KpiSummaryCard(
                        label = "فواتير اليوم",
                        value = "${todayStats.second}",
                        accent = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.weight(0.8f),
                    )
                    KpiSummaryCard(
                        label = "نواقص المخزون",
                        value = "$lowStockCount",
                        accent = if (lowStockCount > 0) WarningAmber else SuccessGreen,
                        modifier = Modifier.weight(0.9f),
                    )
                }

                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("ابحث برقم الفاتورة أو اسم العميل...") },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Filled.Clear, contentDescription = "مسح")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth(),
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = statusFilter == null,
                        onClick = { statusFilter = null },
                        label = { Text("الكل (${invoices.size})") },
                    )
                    FilterChip(
                        selected = statusFilter == InvoiceStatus.COMPLETED,
                        onClick = { statusFilter = InvoiceStatus.COMPLETED },
                        label = { Text("مكتملة") },
                    )
                    FilterChip(
                        selected = statusFilter == InvoiceStatus.REFUNDED,
                        onClick = { statusFilter = InvoiceStatus.REFUNDED },
                        label = { Text("مرتجعة") },
                    )
                }

                val filtered = remember(invoices, searchQuery, statusFilter) {
                    val q = searchQuery.trim()
                    invoices.filter { inv ->
                        val matchesStatus = statusFilter == null || inv.resolvedStatus() == statusFilter
                        val matchesQuery = q.isEmpty() ||
                            inv.invoiceNumber.contains(q, ignoreCase = true) ||
                            inv.customerName.contains(q, ignoreCase = true)
                        matchesStatus && matchesQuery
                    }
                }

                if (filtered.isEmpty()) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Icon(
                                Icons.Filled.ReceiptLong,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.outline,
                                modifier = Modifier.size(48.dp),
                            )
                            Text("لا توجد فواتير مطابقة", style = MaterialTheme.typography.titleMedium)
                        }
                    }
                } else {
                    LazyColumn(
                        contentPadding = PaddingValues(bottom = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        items(filtered, key = { it.id }) { invoice ->
                            InvoiceRowCard(
                                invoice = invoice,
                                currency = settings.currencySymbol,
                                onClick = { onSelectInvoice(invoice) },
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun KpiSummaryCard(
    label: String,
    value: String,
    accent: androidx.compose.ui.graphics.Color,
    modifier: Modifier = Modifier,
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surfaceContainerLowest,
        tonalElevation = 2.dp,
        border = BorderStroke(1.dp, accent.copy(alpha = 0.28f)),
        modifier = modifier,
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
                text = value,
                fontFamily = JetBrainsMonoFontFamily,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = accent,
            )
        }
    }
}

@Composable
private fun InvoiceRowCard(
    invoice: Invoice,
    currency: String,
    onClick: () -> Unit,
) {
    val isRefunded = invoice.resolvedStatus() == InvoiceStatus.REFUNDED
    val dateStr = SimpleDateFormat("MM/dd  HH:mm", Locale.US)
        .format(invoice.createdAt?.toDate() ?: Date())

    Card(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f)),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(3.dp),
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text(
                        text = invoice.invoiceNumber,
                        fontFamily = JetBrainsMonoFontFamily,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                    )
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (isRefunded) {
                            MaterialTheme.colorScheme.errorContainer
                        } else {
                            MaterialTheme.colorScheme.primaryContainer
                        },
                    ) {
                        Text(
                            text = invoice.resolvedStatus().labelAr,
                            style = MaterialTheme.typography.labelSmall,
                            color = if (isRefunded) {
                                MaterialTheme.colorScheme.onErrorContainer
                            } else {
                                MaterialTheme.colorScheme.onPrimaryContainer
                            },
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                        )
                    }
                }
                Text(
                    text = "${invoice.customerName.ifBlank { "عميل نقدي" }} • ${invoice.itemCount} أصناف • ${invoice.resolvedPaymentMethod().labelAr}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Text(
                    text = dateStr,
                    fontFamily = JetBrainsMonoFontFamily,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.outline,
                )
            }

            Text(
                text = formatMoney(invoice.totalAmount, currency),
                fontFamily = JetBrainsMonoFontFamily,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = if (isRefunded) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
            )
        }
    }
}
