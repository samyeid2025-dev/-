package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand Emerald & Warm Gold POS Palette
val EmeraldPrimary = Color(0xFF0F4C45)
val EmeraldOnPrimary = Color(0xFFFFFFFF)
val EmeraldPrimaryContainer = Color(0xFFC5ECE4)
val EmeraldOnPrimaryContainer = Color(0xFF03211D)

val GoldSecondary = Color(0xFFB37B1F)
val GoldOnSecondary = Color(0xFFFFFFFF)
val GoldSecondaryContainer = Color(0xFFFFE5B8)
val GoldOnSecondaryContainer = Color(0xFF2B1900)

val TealTertiary = Color(0xFF28656C)
val TealOnTertiary = Color(0xFFFFFFFF)
val TealTertiaryContainer = Color(0xFFBDEAF0)
val TealOnTertiaryContainer = Color(0xFF002023)

val SurfaceLight = Color(0xFFF6F8F7)
val SurfaceCardLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFE3EBE8)
val OnSurfaceLight = Color(0xFF151D1B)
val OnSurfaceVariantLight = Color(0xFF42504C)
val OutlineLight = Color(0xFF71807B)
val OutlineVariantLight = Color(0xFFC5D2CD)

// Dark Theme Tokens
val EmeraldPrimaryDark = Color(0xFF8BD8CA)
val EmeraldOnPrimaryDark = Color(0xFF003731)
val EmeraldPrimaryContainerDark = Color(0xFF075144)
val EmeraldOnPrimaryContainerDark = Color(0xFFC5ECE4)

val GoldSecondaryDark = Color(0xFFF2C26B)
val GoldOnSecondaryDark = Color(0xFF442C00)
val GoldSecondaryContainerDark = Color(0xFF614000)
val GoldOnSecondaryContainerDark = Color(0xFFFFE5B8)

val TealTertiaryDark = Color(0xFF9DD0D7)
val TealOnTertiaryDark = Color(0xFF00363C)
val TealTertiaryContainerDark = Color(0xFF134E55)
val TealOnTertiaryContainerDark = Color(0xFFBDEAF0)

val SurfaceDark = Color(0xFF0E1513)
val SurfaceCardDark = Color(0xFF161F1C)
val SurfaceVariantDark = Color(0xFF25322E)
val OnSurfaceDark = Color(0xFFE2EAE7)
val OnSurfaceVariantDark = Color(0xFFB8C6C1)
val OutlineDark = Color(0xFF83928D)
val OutlineVariantDark = Color(0xFF394742)

// Semantic Status Colors
val SuccessGreen = Color(0xFF157F4D)
val WarningAmber = Color(0xFFC77700)
val ErrorCrimson = Color(0xFFBA1A1A)
val ErrorContainerLight = Color(0xFFFFDAD6)
val OnErrorContainerLight = Color(0xFF410002)
