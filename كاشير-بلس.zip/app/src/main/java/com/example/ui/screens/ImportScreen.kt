package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckBox
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.importer.FileProductImporter
import com.example.data.model.ImportedProductDraft
import com.example.data.model.ProductUnit
import com.example.data.model.StoreSettings
import com.example.data.model.TrackingType
import com.example.data.model.UnitType
import com.example.data.model.formatMoney
import com.example.data.model.formatQuantity
import com.example.ui.viewmodel.ImportUiState

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ImportScreen(
    importState: ImportUiState,
    settings: StoreSettings,
    onFilePicked: (android.net.Uri) -> Unit,
    onToggleSelect: (String) -> Unit,
    onSelectAll: (Boolean) -> Unit,
    onUpdateDraft: (ImportedProductDraft) -> Unit,
    onAddManualUnit: (String, ProductUnit) -> Unit,
    onUpdateTrackingType: (String, TrackingType) -> Unit,
    onClearDrafts: () -> Unit,
    onCommitImport: () -> Unit,
) {
    val context = LocalContext.current
    var editingDraft by remember { mutableStateOf<ImportedProductDraft?>(null) }

    val pdfPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument(),
        onResult = { uri -> uri?.let(onFilePicked) }
    )

    val excelPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument(),
        onResult = { uri -> uri?.let(onFilePicked) }
    )

    val templateSaverLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/csv"),
        onResult = { uri ->
            if (uri != null) {
                try {
                    context.contentResolver.openOutputStream(uri)?.use { out ->
                        out.write(FileProductImporter.buildSampleCsvTemplate().toByteArray(Charsets.UTF_8))
                    }
                    Toast.makeText(context, "تم حفظ قالب Excel/CSV بنجاح", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(context, "تعذر حفظ الملف: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        // Header Picker Card
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier.size(44.dp),
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                Icons.Filled.UploadFile,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                            )
                        }
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "استيراد الأصناف من PDF و Excel",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                        )
                        Text(
                            text = "يدعم ملفات Excel (.xlsx, .xls, .csv) وملفات PDF مع التعرف التلقائي على الوحدات والأسعار.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Button(
                        onClick = {
                            excelPickerLauncher.launch(
                                arrayOf(
                                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                    "application/vnd.ms-excel",
                                    "text/csv",
                                    "text/comma-separated-values",
                                    "text/plain",
                                    "application/octet-stream",
                                )
                            )
                        },
                        enabled = !importState.isParsing && !importState.isImporting,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp)
                            .testTag("pick_excel_button"),
                    ) {
                        Icon(Icons.Filled.TableChart, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("ملف Excel")
                    }

                    Button(
                        onClick = {
                            pdfPickerLauncher.launch(arrayOf("application/pdf"))
                        },
                        enabled = !importState.isParsing && !importState.isImporting,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.secondary
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp)
                            .testTag("pick_pdf_button"),
                    ) {
                        Icon(Icons.Filled.PictureAsPdf, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("ملف PDF")
                    }
                }

                OutlinedButton(
                    onClick = { templateSaverLauncher.launch("cashier_products_template.csv") },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp),
                ) {
                    Icon(Icons.Filled.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("تنزيل قالب Excel نموذجي متعدد الوحدات")
                }
            }
        }

        if (importState.isParsing) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                contentAlignment = Alignment.Center,
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    CircularProgressIndicator()
                    Text("جاري قراءة وتحليل الملف...", style = MaterialTheme.typography.bodyMedium)
                }
            }
        }

        if (importState.errorMessage != null) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(
                    text = importState.errorMessage,
                    color = MaterialTheme.colorScheme.onErrorContainer,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(14.dp),
                )
            }
        }

        if (importState.drafts.isNotEmpty()) {
            val selectedCount = importState.drafts.count { it.selected }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "${importState.fileName} (${importState.fileTypeLabel})",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                    )
                    Text(
                        text = "تم التعرف على ${importState.drafts.size} صنف • محدد: $selectedCount",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Row {
                    TextButton(onClick = { onSelectAll(selectedCount < importState.drafts.size) }) {
                        Text(if (selectedCount < importState.drafts.size) "تحديد الكل" else "إلغاء الكل")
                    }
                    IconButton(onClick = onClearDrafts) {
                        Icon(Icons.Filled.Clear, contentDescription = "إغلاق المعاينة")
                    }
                }
            }

            LazyColumn(
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(bottom = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(importState.drafts, key = { it.localId }) { draft ->
                    ImportedDraftCard(
                        draft = draft,
                        currency = settings.currencySymbol,
                        onToggle = { onToggleSelect(draft.localId) },
                        onToggleTracking = {
                            val next = if (draft.trackingType == TrackingType.COUNT) {
                                TrackingType.WEIGHT
                            } else {
                                TrackingType.COUNT
                            }
                            onUpdateTrackingType(draft.localId, next)
                        },
                        onEdit = { editingDraft = draft },
                    )
                }
            }

            Button(
                onClick = onCommitImport,
                enabled = selectedCount > 0 && !importState.isImporting,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("commit_import_button"),
            ) {
                if (importState.isImporting) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(22.dp),
                        color = MaterialTheme.colorScheme.onPrimary,
                        strokeWidth = 2.dp,
                    )
                } else {
                    Icon(Icons.Filled.CheckBox, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("استيراد $selectedCount صنف إلى المخزون", style = MaterialTheme.typography.titleMedium)
                }
            }
        } else if (!importState.isParsing) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center,
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(20.dp),
                ) {
                    Icon(
                        Icons.Filled.Description,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.outline,
                        modifier = Modifier.size(52.dp),
                    )
                    Text(
                        text = "اختر ملف PDF أو Excel للمعاينة",
                        style = MaterialTheme.typography.titleMedium,
                    )
                    Text(
                        text = "يمكنك مراجعة الأسماء والأسعار وإضافة وحدات (قطعة / كرتونة / كيلو) لكل صنف قبل الحفظ النهائي.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }

    editingDraft?.let { draft ->
        DraftEditDialog(
            draft = draft,
            currency = settings.currencySymbol,
            onDismiss = { editingDraft = null },
            onSave = { updated ->
                onUpdateDraft(updated)
                editingDraft = null
            },
            onAddUnit = { unit ->
                onAddManualUnit(draft.localId, unit)
                editingDraft = null
            },
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ImportedDraftCard(
    draft: ImportedProductDraft,
    currency: String,
    onToggle: () -> Unit,
    onToggleTracking: () -> Unit,
    onEdit: () -> Unit,
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
        border = BorderStroke(
            1.dp,
            if (draft.selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.45f)
            else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f),
        ),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Checkbox(
                    checked = draft.selected,
                    onCheckedChange = { onToggle() },
                )
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = draft.name,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                    )
                    Text(
                        text = "المخزون: ${formatQuantity(draft.stockInBaseUnits)} ${draft.baseUnitName} • ${draft.category}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                TextButton(onClick = onEdit) {
                    Text("تعديل / وحدة")
                }
            }

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                FilterChip(
                    selected = draft.trackingType == TrackingType.WEIGHT,
                    onClick = onToggleTracking,
                    label = {
                        Text(if (draft.trackingType == TrackingType.WEIGHT) "بيع بالوزن" else "بيع بالعدد")
                    },
                )
                draft.units.forEach { u ->
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.primaryContainer,
                    ) {
                        Text(
                            text = "${u.unitName}: ${formatMoney(u.price, currency)}",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DraftEditDialog(
    draft: ImportedProductDraft,
    currency: String,
    onDismiss: () -> Unit,
    onSave: (ImportedProductDraft) -> Unit,
    onAddUnit: (ProductUnit) -> Unit,
) {
    var name by remember { mutableStateOf(draft.name) }
    var stockStr by remember { mutableStateOf(formatQuantity(draft.stockInBaseUnits)) }
    var primaryPriceStr by remember { mutableStateOf(formatQuantity(draft.units.firstOrNull()?.price ?: 0.0)) }
    var extraUnitName by remember { mutableStateOf("") }
    var extraFactorStr by remember { mutableStateOf("12") }
    var extraPriceStr by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تعديل الصنف المستورد", style = MaterialTheme.typography.titleMedium) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("اسم الصنف") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = primaryPriceStr,
                        onValueChange = { primaryPriceStr = it },
                        label = { Text("سعر ${draft.baseUnitName} ($currency)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                    )
                    OutlinedTextField(
                        value = stockStr,
                        onValueChange = { stockStr = it },
                        label = { Text("المخزون") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                    )
                }

                Text("إضافة وحدة إضافية (مثل كرتونة أو جرام):", style = MaterialTheme.typography.labelMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(
                        value = extraUnitName,
                        onValueChange = { extraUnitName = it },
                        placeholder = { Text("كرتونة") },
                        label = { Text("الوحدة") },
                        singleLine = true,
                        modifier = Modifier.weight(1.2f),
                    )
                    OutlinedTextField(
                        value = extraFactorStr,
                        onValueChange = { extraFactorStr = it },
                        label = { Text("المعامل") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(0.9f),
                    )
                    OutlinedTextField(
                        value = extraPriceStr,
                        onValueChange = { extraPriceStr = it },
                        label = { Text("السعر") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val updatedUnits = draft.units.mapIndexed { idx, unit ->
                        if (idx == 0) unit.copy(price = primaryPriceStr.toDoubleOrNull() ?: unit.price)
                        else unit
                    }.toMutableList()

                    if (extraUnitName.isNotBlank()) {
                        val unitType = UnitType.detectFromName(extraUnitName)
                        updatedUnits.add(
                            ProductUnit(
                                unitName = extraUnitName.trim(),
                                unitType = unitType.name,
                                conversionFactor = (extraFactorStr.toDoubleOrNull() ?: 1.0).coerceAtLeast(0.001),
                                price = (extraPriceStr.toDoubleOrNull() ?: 0.0).coerceAtLeast(0.0),
                                allowDecimal = unitType == UnitType.KG,
                            )
                        )
                    }

                    onSave(
                        draft.copy(
                            name = name.trim().ifEmpty { draft.name },
                            stockInBaseUnits = (stockStr.toDoubleOrNull() ?: draft.stockInBaseUnits).coerceAtLeast(0.0),
                            units = updatedUnits.take(10),
                        )
                    )
                }
            ) {
                Text("حفظ")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        },
    )
}
