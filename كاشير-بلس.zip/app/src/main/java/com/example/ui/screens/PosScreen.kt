package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddShoppingCart
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Scale
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.CartItem
import com.example.data.model.PaymentMethod
import com.example.data.model.Product
import com.example.data.model.ProductUnit
import com.example.data.model.StoreSettings
import com.example.data.model.TrackingType
import com.example.data.model.UiState
import com.example.data.model.formatMoney
import com.example.data.model.formatQuantity
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.WarningAmber
import com.example.ui.viewmodel.CartSummary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PosScreen(
    productsState: UiState<List<Product>>,
    settings: StoreSettings,
    cartItems: List<CartItem>,
    cartSummary: CartSummary,
    discountInput: String,
    discountIsPercent: Boolean,
    customerName: String,
    paymentMethod: PaymentMethod,
    paidAmountInput: String,
    isCheckingOut: Boolean,
    onAddToCart: (Product, ProductUnit, Double) -> Unit,
    onUpdateQuantity: (String, Double) -> Unit,
    onSwitchUnit: (String, ProductUnit) -> Unit,
    onClearCart: () -> Unit,
    onDiscountChange: (String) -> Unit,
    onDiscountPercentToggle: (Boolean) -> Unit,
    onCustomerNameChange: (String) -> Unit,
    onPaymentMethodChange: (PaymentMethod) -> Unit,
    onPaidAmountChange: (String) -> Unit,
    onCheckout: () -> Unit,
    onNavigateToImport: () -> Unit,
    onNavigateToInventory: () -> Unit,
    onSeedSamples: () -> Unit,
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("الكل") }
    var showCartSheet by remember { mutableStateOf(false) }
    var quantityDialogTarget by remember { mutableStateOf<Pair<Product, ProductUnit>?>(null) }
    var cartItemQuantityDialog by remember { mutableStateOf<CartItem?>(null) }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isWideLayout = maxWidth >= 760.dp

        Row(modifier = Modifier.fillMaxSize()) {
            // Left / Primary Pane: Product Catalog
            Box(
                modifier = Modifier
                    .weight(if (isWideLayout) 1.35f else 1f)
                    .fillMaxHeight()
            ) {
                Column(modifier = Modifier.fillMaxSize()) {
                    // Search Bar
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("ابحث بالاسم أو الباركود...") },
                        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(Icons.Filled.Clear, contentDescription = "مسح البحث")
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 10.dp)
                            .testTag("pos_search_input"),
                    )

                    when (productsState) {
                        is UiState.Loading -> {
                            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                CircularProgressIndicator()
                            }
                        }

                        is UiState.Error -> {
                            Box(
                                Modifier
                                    .fillMaxSize()
                                    .padding(24.dp),
                                contentAlignment = Alignment.Center,
                            ) {
                                Text(
                                    text = productsState.message,
                                    color = MaterialTheme.colorScheme.error,
                                    style = MaterialTheme.typography.bodyLarge,
                                )
                            }
                        }

                        is UiState.Success -> {
                            val products = productsState.data
                            if (products.isEmpty()) {
                                EmptyPosCatalogCard(
                                    onNavigateToImport = onNavigateToImport,
                                    onNavigateToInventory = onNavigateToInventory,
                                    onSeedSamples = onSeedSamples,
                                )
                            } else {
                                val categories = remember(products) {
                                    listOf("الكل") + products.map { it.category.ifBlank { "عام" } }
                                        .distinct()
                                        .sorted()
                                }
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState())
                                        .padding(horizontal = 16.dp, vertical = 2.dp),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                ) {
                                    categories.forEach { category ->
                                        FilterChip(
                                            selected = selectedCategory == category,
                                            onClick = { selectedCategory = category },
                                            label = { Text(category) },
                                        )
                                    }
                                }

                                val filtered = remember(products, searchQuery, selectedCategory) {
                                    val q = searchQuery.trim()
                                    products.filter { p ->
                                        val matchesCat = selectedCategory == "الكل" ||
                                            p.category.ifBlank { "عام" } == selectedCategory
                                        val matchesQuery = q.isEmpty() ||
                                            p.name.contains(q, ignoreCase = true) ||
                                            p.barcode.contains(q, ignoreCase = true) ||
                                            p.units.any { it.barcode.contains(q, ignoreCase = true) }
                                        matchesCat && matchesQuery
                                    }
                                }

                                LazyVerticalGrid(
                                    columns = GridCells.Adaptive(minSize = 180.dp),
                                    contentPadding = PaddingValues(
                                        start = 16.dp,
                                        end = 16.dp,
                                        top = 8.dp,
                                        bottom = if (!isWideLayout && cartItems.isNotEmpty()) 96.dp else 16.dp,
                                    ),
                                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                                    verticalArrangement = Arrangement.spacedBy(12.dp),
                                    modifier = Modifier.fillMaxSize(),
                                ) {
                                    items(filtered, key = { it.id }) { product ->
                                        PosProductCard(
                                            product = product,
                                            currency = settings.currencySymbol,
                                            onSelectUnit = { unit ->
                                                if (unit.allowDecimal || product.resolvedTrackingType() == TrackingType.WEIGHT) {
                                                    quantityDialogTarget = product to unit
                                                } else {
                                                    onAddToCart(product, unit, 1.0)
                                                }
                                            },
                                            onLongPressUnit = { unit ->
                                                quantityDialogTarget = product to unit
                                            },
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Compact Phone Bottom Checkout Bar
                if (!isWideLayout && cartItems.isNotEmpty()) {
                    Surface(
                        color = MaterialTheme.colorScheme.primary,
                        shape = RoundedCornerShape(20.dp),
                        shadowElevation = 8.dp,
                        onClick = { showCartSheet = true },
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp)
                            .testTag("open_cart_bar"),
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                            ) {
                                Badge(
                                    containerColor = MaterialTheme.colorScheme.secondary,
                                    contentColor = MaterialTheme.colorScheme.onSecondary,
                                ) {
                                    Text(
                                        text = "${cartSummary.totalItemLines}",
                                        fontFamily = JetBrainsMonoFontFamily,
                                        modifier = Modifier.padding(horizontal = 4.dp),
                                    )
                                }
                                Text(
                                    text = "عرض السلة والدفع",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.onPrimary,
                                )
                            }
                            Text(
                                text = formatMoney(cartSummary.totalAmount, settings.currencySymbol),
                                fontFamily = JetBrainsMonoFontFamily,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimary,
                            )
                        }
                    }
                }
            }

            // Wide Screen Persistent Cart Side Pane
            if (isWideLayout) {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceContainerLowest,
                    tonalElevation = 2.dp,
                    modifier = Modifier
                        .weight(0.95f)
                        .fillMaxHeight(),
                ) {
                    CartCheckoutPanel(
                        cartItems = cartItems,
                        cartSummary = cartSummary,
                        settings = settings,
                        discountInput = discountInput,
                        discountIsPercent = discountIsPercent,
                        customerName = customerName,
                        paymentMethod = paymentMethod,
                        paidAmountInput = paidAmountInput,
                        isCheckingOut = isCheckingOut,
                        onUpdateQuantity = onUpdateQuantity,
                        onEditQuantityClick = { cartItemQuantityDialog = it },
                        onSwitchUnit = onSwitchUnit,
                        onClearCart = onClearCart,
                        onDiscountChange = onDiscountChange,
                        onDiscountPercentToggle = onDiscountPercentToggle,
                        onCustomerNameChange = onCustomerNameChange,
                        onPaymentMethodChange = onPaymentMethodChange,
                        onPaidAmountChange = onPaidAmountChange,
                        onCheckout = onCheckout,
                    )
                }
            }
        }
    }

    if (showCartSheet) {
        ModalBottomSheet(
            onDismissRequest = { showCartSheet = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(620.dp)
            ) {
                CartCheckoutPanel(
                    cartItems = cartItems,
                    cartSummary = cartSummary,
                    settings = settings,
                    discountInput = discountInput,
                    discountIsPercent = discountIsPercent,
                    customerName = customerName,
                    paymentMethod = paymentMethod,
                    paidAmountInput = paidAmountInput,
                    isCheckingOut = isCheckingOut,
                    onUpdateQuantity = onUpdateQuantity,
                    onEditQuantityClick = { cartItemQuantityDialog = it },
                    onSwitchUnit = onSwitchUnit,
                    onClearCart = {
                        onClearCart()
                        showCartSheet = false
                    },
                    onDiscountChange = onDiscountChange,
                    onDiscountPercentToggle = onDiscountPercentToggle,
                    onCustomerNameChange = onCustomerNameChange,
                    onPaymentMethodChange = onPaymentMethodChange,
                    onPaidAmountChange = onPaidAmountChange,
                    onCheckout = {
                        onCheckout()
                        showCartSheet = false
                    },
                )
            }
        }
    }

    quantityDialogTarget?.let { (product, unit) ->
        QuantityInputDialog(
            title = "${product.name} (${unit.unitName})",
            unitLabel = unit.unitName,
            initialQty = 1.0,
            allowDecimal = unit.allowDecimal || product.resolvedTrackingType() == TrackingType.WEIGHT,
            onDismiss = { quantityDialogTarget = null },
            onConfirm = { qty ->
                onAddToCart(product, unit, qty)
                quantityDialogTarget = null
            },
        )
    }

    cartItemQuantityDialog?.let { cartItem ->
        QuantityInputDialog(
            title = "${cartItem.product.name} (${cartItem.unit.unitName})",
            unitLabel = cartItem.unit.unitName,
            initialQty = cartItem.quantity,
            allowDecimal = cartItem.unit.allowDecimal || cartItem.product.resolvedTrackingType() == TrackingType.WEIGHT,
            onDismiss = { cartItemQuantityDialog = null },
            onConfirm = { qty ->
                onUpdateQuantity(cartItem.key, qty)
                cartItemQuantityDialog = null
            },
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun PosProductCard(
    product: Product,
    currency: String,
    onSelectUnit: (ProductUnit) -> Unit,
    onLongPressUnit: (ProductUnit) -> Unit,
) {
    val isWeight = product.resolvedTrackingType() == TrackingType.WEIGHT
    val lowStock = product.isLowStockFlag()

    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        border = BorderStroke(
            1.dp,
            if (lowStock) WarningAmber.copy(alpha = 0.5f) else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f),
        ),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("pos_product_card_${product.id}"),
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerHigh,
                ) {
                    Text(
                        text = product.category.ifBlank { "عام" },
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                    )
                }
                if (isWeight) {
                    Icon(
                        imageVector = Icons.Filled.Scale,
                        contentDescription = "يباع بالوزن",
                        tint = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.size(16.dp),
                    )
                }
            }

            Text(
                text = product.name,
                style = MaterialTheme.typography.titleMedium,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )

            Text(
                text = "المخزون: ${formatQuantity(product.stockInBaseUnits)} ${product.baseUnitName}",
                style = MaterialTheme.typography.bodySmall,
                color = if (lowStock) WarningAmber else MaterialTheme.colorScheme.onSurfaceVariant,
                fontWeight = if (lowStock) FontWeight.Bold else FontWeight.Normal,
            )

            // Multi-unit quick add pills
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth(),
            ) {
                product.units.forEach { unit ->
                    Surface(
                        onClick = { onSelectUnit(unit) },
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.primaryContainer,
                        contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.testTag("add_unit_${product.id}_${unit.unitName}"),
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                        ) {
                            Icon(
                                imageVector = Icons.Filled.AddShoppingCart,
                                contentDescription = "إضافة ${unit.unitName}",
                                modifier = Modifier.size(14.dp),
                            )
                            Text(
                                text = "${unit.unitName}: ${formatMoney(unit.price, currency)}",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                            )
                        }
                    }
                }
            }

            // Optional custom qty trigger for quick bulk/weight entry
            val firstUnit = product.primaryUnit()
            TextButton(
                onClick = { onLongPressUnit(firstUnit) },
                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp),
                modifier = Modifier.height(30.dp),
            ) {
                Text(
                    text = if (isWeight) "إدخال وزن مخصص" else "إدخال كمية مخصصة",
                    style = MaterialTheme.typography.labelSmall,
                )
            }
        }
    }
}

@Composable
private fun CartCheckoutPanel(
    cartItems: List<CartItem>,
    cartSummary: CartSummary,
    settings: StoreSettings,
    discountInput: String,
    discountIsPercent: Boolean,
    customerName: String,
    paymentMethod: PaymentMethod,
    paidAmountInput: String,
    isCheckingOut: Boolean,
    onUpdateQuantity: (String, Double) -> Unit,
    onEditQuantityClick: (CartItem) -> Unit,
    onSwitchUnit: (String, ProductUnit) -> Unit,
    onClearCart: () -> Unit,
    onDiscountChange: (String) -> Unit,
    onDiscountPercentToggle: (Boolean) -> Unit,
    onCustomerNameChange: (String) -> Unit,
    onPaymentMethodChange: (PaymentMethod) -> Unit,
    onPaidAmountChange: (String) -> Unit,
    onCheckout: () -> Unit,
) {
    val currency = settings.currencySymbol

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Icon(Icons.Filled.ShoppingCart, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Text("فاتورة البيع الحالية", style = MaterialTheme.typography.titleLarge)
            }
            if (cartItems.isNotEmpty()) {
                TextButton(onClick = onClearCart) {
                    Text("تفريغ", color = MaterialTheme.colorScheme.error)
                }
            }
        }

        if (cartItems.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center,
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Icon(
                        imageVector = Icons.Filled.PointOfSale,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.outline,
                        modifier = Modifier.size(48.dp),
                    )
                    Text(
                        text = "السلة فارغة — اضغط على وحدة الصنف لإضافته",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(cartItems, key = { it.key }) { item ->
                    CartLineCard(
                        item = item,
                        currency = currency,
                        onUpdateQuantity = { q -> onUpdateQuantity(item.key, q) },
                        onEditQuantityClick = { onEditQuantityClick(item) },
                        onSwitchUnit = { newUnit -> onSwitchUnit(item.key, newUnit) },
                    )
                }

                item {
                    Spacer(Modifier.height(4.dp))
                    HorizontalDivider()
                    Spacer(Modifier.height(8.dp))

                    // Discount & Customer Inputs
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        OutlinedTextField(
                            value = discountInput,
                            onValueChange = onDiscountChange,
                            label = { Text(if (discountIsPercent) "خصم (%)" else "خصم ($currency)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier.weight(1f),
                        )
                        FilterChip(
                            selected = discountIsPercent,
                            onClick = { onDiscountPercentToggle(!discountIsPercent) },
                            label = { Text(if (discountIsPercent) "نسبة %" else "مبلغ ثابت") },
                        )
                    }

                    Spacer(Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        OutlinedTextField(
                            value = customerName,
                            onValueChange = onCustomerNameChange,
                            label = { Text("اسم العميل (اختياري)") },
                            singleLine = true,
                            modifier = Modifier.weight(1f),
                        )
                        OutlinedTextField(
                            value = paidAmountInput,
                            onValueChange = onPaidAmountChange,
                            label = { Text("المبلغ المدفوع") },
                            placeholder = { Text(formatQuantity(cartSummary.totalAmount)) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier.weight(1f),
                        )
                    }

                    Spacer(Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        PaymentMethod.entries.forEach { method ->
                            FilterChip(
                                selected = paymentMethod == method,
                                onClick = { onPaymentMethodChange(method) },
                                label = { Text(method.labelAr) },
                            )
                        }
                    }
                }
            }

            // Summary Totals & Checkout CTA
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surfaceContainer,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("المجموع الفرعي", style = MaterialTheme.typography.bodySmall)
                        Text(
                            formatMoney(cartSummary.subtotal, currency),
                            fontFamily = JetBrainsMonoFontFamily,
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                    if (cartSummary.discountAmount > 0.0) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("الخصم", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
                            Text(
                                "- ${formatMoney(cartSummary.discountAmount, currency)}",
                                fontFamily = JetBrainsMonoFontFamily,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.secondary,
                            )
                        }
                    }
                    if (cartSummary.taxAmount > 0.0) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("الضريبة (${formatQuantity(settings.taxRatePercent)}%)", style = MaterialTheme.typography.bodySmall)
                            Text(
                                formatMoney(cartSummary.taxAmount, currency),
                                fontFamily = JetBrainsMonoFontFamily,
                                style = MaterialTheme.typography.bodySmall,
                            )
                        }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("الإجمالي", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(
                            formatMoney(cartSummary.totalAmount, currency),
                            fontFamily = JetBrainsMonoFontFamily,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                        )
                    }
                    if (cartSummary.changeAmount > 0.0) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("الباقي للعميل", style = MaterialTheme.typography.bodySmall)
                            Text(
                                formatMoney(cartSummary.changeAmount, currency),
                                fontFamily = JetBrainsMonoFontFamily,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                            )
                        }
                    }
                }
            }

            Button(
                onClick = onCheckout,
                enabled = !isCheckingOut && cartItems.isNotEmpty(),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("checkout_button"),
            ) {
                if (isCheckingOut) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(22.dp),
                        color = MaterialTheme.colorScheme.onPrimary,
                        strokeWidth = 2.dp,
                    )
                } else {
                    Icon(Icons.Filled.CheckCircle, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("إتمام البيع وإصدار الفاتورة", style = MaterialTheme.typography.titleMedium)
                }
            }
        }
    }
}

@Composable
private fun CartLineCard(
    item: CartItem,
    currency: String,
    onUpdateQuantity: (Double) -> Unit,
    onEditQuantityClick: () -> Unit,
    onSwitchUnit: (ProductUnit) -> Unit,
) {
    val step = if (item.unit.allowDecimal) 0.25 else 1.0
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surfaceContainerLow,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f)),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = item.product.name,
                    style = MaterialTheme.typography.titleSmall,
                    modifier = Modifier.weight(1f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                IconButton(
                    onClick = { onUpdateQuantity(0.0) },
                    modifier = Modifier.size(32.dp),
                ) {
                    Icon(
                        imageVector = Icons.Filled.DeleteOutline,
                        contentDescription = "حذف من السلة",
                        tint = MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(18.dp),
                    )
                }
            }

            // Unit Switcher inside Cart
            if (item.product.units.size > 1) {
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    item.product.units.forEach { u ->
                        FilterChip(
                            selected = u.unitName == item.unit.unitName,
                            onClick = { onSwitchUnit(u) },
                            label = { Text("${u.unitName} (${formatMoney(u.price, currency)})") },
                        )
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    IconButton(
                        onClick = { onUpdateQuantity(item.quantity - step) },
                        modifier = Modifier.size(36.dp),
                    ) {
                        Icon(Icons.Filled.Remove, contentDescription = "إنقاص الكمية")
                    }
                    Surface(
                        onClick = onEditQuantityClick,
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surfaceContainerHigh,
                    ) {
                        Text(
                            text = "${formatQuantity(item.quantity)} ${item.unit.unitName}",
                            fontFamily = JetBrainsMonoFontFamily,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        )
                    }
                    IconButton(
                        onClick = { onUpdateQuantity(item.quantity + step) },
                        modifier = Modifier.size(36.dp),
                    ) {
                        Icon(Icons.Filled.Add, contentDescription = "زيادة الكمية")
                    }
                }

                Text(
                    text = formatMoney(item.lineTotal, currency),
                    fontFamily = JetBrainsMonoFontFamily,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                )
            }
        }
    }
}

@Composable
private fun QuantityInputDialog(
    title: String,
    unitLabel: String,
    initialQty: Double,
    allowDecimal: Boolean,
    onDismiss: () -> Unit,
    onConfirm: (Double) -> Unit,
) {
    var input by remember(initialQty) { mutableStateOf(formatQuantity(initialQty)) }
    val presets = if (allowDecimal) listOf(0.25, 0.5, 1.0, 1.5, 2.0, 5.0) else listOf(1.0, 2.0, 5.0, 10.0, 12.0, 24.0)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, style = MaterialTheme.typography.titleMedium) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    label = { Text("الكمية / الوزن ($unitLabel)") },
                    keyboardOptions = KeyboardOptions(
                        keyboardType = if (allowDecimal) KeyboardType.Decimal else KeyboardType.Number
                    ),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    presets.forEach { preset ->
                        FilterChip(
                            selected = input.toDoubleOrNull() == preset,
                            onClick = { input = formatQuantity(preset) },
                            label = { Text(formatQuantity(preset)) },
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val qty = input.toDoubleOrNull() ?: 0.0
                    if (qty > 0.0) onConfirm(qty)
                }
            ) {
                Text("تأكيد")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        },
    )
}

@Composable
private fun EmptyPosCatalogCard(
    onNavigateToImport: () -> Unit,
    onNavigateToInventory: () -> Unit,
    onSeedSamples: () -> Unit,
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        contentAlignment = Alignment.Center,
    ) {
        Card(
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column(
                modifier = Modifier.padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Icon(
                    imageVector = Icons.Filled.PointOfSale,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(48.dp),
                )
                Text(
                    text = "ابدأ بإضافة أصناف متجرك",
                    style = MaterialTheme.typography.titleLarge,
                )
                Text(
                    text = "يمكنك استيراد قائمة المنتجات مباشرة من ملف PDF أو Excel، أو إضافة الأصناف يدوياً بتعدد الوحدات (قطعة، كرتونة، وزن).",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Button(
                    onClick = onNavigateToImport,
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                ) {
                    Icon(Icons.Filled.UploadFile, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("استيراد من PDF أو Excel")
                }
                OutlinedButton(
                    onClick = onNavigateToInventory,
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                ) {
                    Icon(Icons.Filled.Add, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("إضافة صنف يدوياً")
                }
                TextButton(onClick = onSeedSamples) {
                    Text("أو تحميل 4 أصناف تجريبية متعددة الوحدات للتجربة")
                }
            }
        }
    }
}
