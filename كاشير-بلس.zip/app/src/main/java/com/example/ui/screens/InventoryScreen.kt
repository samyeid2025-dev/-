package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Scale
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.model.Product
import com.example.data.model.ProductUnit
import com.example.data.model.StoreSettings
import com.example.data.model.TrackingType
import com.example.data.model.UiState
import com.example.data.model.UnitType
import com.example.data.model.formatMoney
import com.example.data.model.formatQuantity
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.WarningAmber

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun InventoryScreen(
    productsState: UiState<List<Product>>,
    settings: StoreSettings,
    onSaveProduct: (Product, () -> Unit) -> Unit,
    onDeleteProduct: (String) -> Unit,
    onNavigateToImport: () -> Unit,
) {
    var searchQuery by remember { mutableStateOf("") }
    var onlyLowStock by remember { mutableStateOf(false) }
    var editingProduct by remember { mutableStateOf<Product?>(null) }
    var showEditorSheet by remember { mutableStateOf(false) }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    editingProduct = Product()
                    showEditorSheet = true
                },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.testTag("add_product_fab"),
            ) {
                Icon(Icons.Filled.Add, contentDescription = "إضافة صنف جديد")
            }
        },
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("ابحث في الأصناف أو الباركود...") },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Filled.Clear, contentDescription = "مسح")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.weight(1f),
                )
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                FilterChip(
                    selected = onlyLowStock,
                    onClick = { onlyLowStock = !onlyLowStock },
                    leadingIcon = {
                        Icon(
                            Icons.Filled.WarningAmber,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp),
                        )
                    },
                    label = { Text("نواقص المخزون فقط") },
                )
                TextButton(onClick = onNavigateToImport) {
                    Text("استيراد PDF / Excel")
                }
            }

            when (productsState) {
                is UiState.Loading -> {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                }

                is UiState.Error -> {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(productsState.message, color = MaterialTheme.colorScheme.error)
                    }
                }

                is UiState.Success -> {
                    val q = searchQuery.trim()
                    val list = productsState.data.filter { p ->
                        val matchesQuery = q.isEmpty() ||
                            p.name.contains(q, ignoreCase = true) ||
                            p.barcode.contains(q, ignoreCase = true) ||
                            p.category.contains(q, ignoreCase = true)
                        val matchesStock = !onlyLowStock || p.isLowStockFlag()
                        matchesQuery && matchesStock
                    }

                    if (list.isEmpty()) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                Icon(
                                    Icons.Filled.Inventory2,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.outline,
                                    modifier = Modifier.size(48.dp),
                                )
                                Text(
                                    text = if (onlyLowStock) "لا توجد أصناف منخفضة المخزون" else "لا توجد أصناف مسجلة",
                                    style = MaterialTheme.typography.titleMedium,
                                )
                            }
                        }
                    } else {
                        LazyColumn(
                            contentPadding = PaddingValues(bottom = 88.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            items(list, key = { it.id }) { product ->
                                InventoryProductCard(
                                    product = product,
                                    currency = settings.currencySymbol,
                                    onEdit = {
                                        editingProduct = product
                                        showEditorSheet = true
                                    },
                                    onDelete = { onDeleteProduct(product.id) },
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showEditorSheet && editingProduct != null) {
        ModalBottomSheet(
            onDismissRequest = { showEditorSheet = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        ) {
            ProductEditorSheetContent(
                initial = editingProduct!!,
                currency = settings.currencySymbol,
                onDismiss = { showEditorSheet = false },
                onSave = { saved ->
                    onSaveProduct(saved) {
                        showEditorSheet = false
                    }
                },
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun InventoryProductCard(
    product: Product,
    currency: String,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
) {
    val lowStock = product.isLowStockFlag()
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
        border = BorderStroke(
            1.dp,
            if (lowStock) WarningAmber.copy(alpha = 0.6f) else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f),
        ),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        Text(
                            text = product.name,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                        )
                        if (product.resolvedTrackingType() == TrackingType.WEIGHT) {
                            Icon(
                                Icons.Filled.Scale,
                                contentDescription = "وزن",
                                tint = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.size(16.dp),
                            )
                        }
                    }
                    Text(
                        text = "${product.category} • المخزون: ${formatQuantity(product.stockInBaseUnits)} ${product.baseUnitName}",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (lowStock) WarningAmber else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    if (product.barcode.isNotBlank()) {
                        Text(
                            text = "باركود: ${product.barcode}",
                            fontFamily = JetBrainsMonoFontFamily,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
                Row {
                    IconButton(onClick = onEdit) {
                        Icon(Icons.Filled.Edit, contentDescription = "تعديل الصنف")
                    }
                    IconButton(onClick = onDelete) {
                        Icon(
                            Icons.Filled.DeleteOutline,
                            contentDescription = "حذف الصنف",
                            tint = MaterialTheme.colorScheme.error,
                        )
                    }
                }
            }

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                product.units.forEach { unit ->
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.surfaceContainerHigh,
                    ) {
                        Text(
                            text = "${unit.unitName} (${formatQuantity(unit.conversionFactor)} ${product.baseUnitName}): ${formatMoney(unit.price, currency)}",
                            style = MaterialTheme.typography.labelMedium,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ProductEditorSheetContent(
    initial: Product,
    currency: String,
    onDismiss: () -> Unit,
    onSave: (Product) -> Unit,
) {
    var name by remember { mutableStateOf(initial.name) }
    var barcode by remember { mutableStateOf(initial.barcode) }
    var category by remember { mutableStateOf(initial.category.ifBlank { "عام" }) }
    var trackingType by remember { mutableStateOf(initial.resolvedTrackingType()) }
    var baseUnitName by remember {
        mutableStateOf(
            initial.baseUnitName.ifBlank {
                if (trackingType == TrackingType.WEIGHT) "كيلو" else "قطعة"
            }
        )
    }
    var stockStr by remember { mutableStateOf(formatQuantity(initial.stockInBaseUnits)) }
    var lowStockStr by remember { mutableStateOf(formatQuantity(initial.lowStockThreshold)) }
    var costStr by remember { mutableStateOf(formatQuantity(initial.costPrice)) }

    val unitsList = remember {
        mutableStateListOf<ProductUnit>().apply {
            if (initial.units.isNotEmpty()) {
                addAll(initial.units)
            } else {
                add(
                    ProductUnit(
                        unitName = baseUnitName,
                        unitType = UnitType.PIECE.name,
                        conversionFactor = 1.0,
                        price = 0.0,
                        allowDecimal = trackingType == TrackingType.WEIGHT,
                    )
                )
            }
        }
    }

    var validationError by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text(
            text = if (initial.id.isBlank()) "إضافة صنف جديد" else "تعديل الصنف والوحدات",
            style = MaterialTheme.typography.titleLarge,
        )

        OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text("اسم الصنف *") },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("product_name_input"),
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            OutlinedTextField(
                value = barcode,
                onValueChange = { barcode = it },
                label = { Text("الباركود / الكود") },
                singleLine = true,
                modifier = Modifier.weight(1f),
            )
            OutlinedTextField(
                value = category,
                onValueChange = { category = it },
                label = { Text("الفئة") },
                singleLine = true,
                modifier = Modifier.weight(1f),
            )
        }

        // Tracking Type Toggle (Count vs Weight)
        Text("نوع القياس والبيع", style = MaterialTheme.typography.titleSmall)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            TrackingType.entries.forEach { type ->
                FilterChip(
                    selected = trackingType == type,
                    onClick = {
                        trackingType = type
                        if (type == TrackingType.WEIGHT && baseUnitName == "قطعة") {
                            baseUnitName = "كيلو"
                        } else if (type == TrackingType.COUNT && baseUnitName == "كيلو") {
                            baseUnitName = "قطعة"
                        }
                    },
                    label = { Text(type.labelAr) },
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            OutlinedTextField(
                value = baseUnitName,
                onValueChange = { baseUnitName = it },
                label = { Text("الوحدة الأساسية") },
                singleLine = true,
                modifier = Modifier.weight(1f),
            )
            OutlinedTextField(
                value = stockStr,
                onValueChange = { stockStr = it },
                label = { Text("المخزون الحالي") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                modifier = Modifier.weight(1f),
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            OutlinedTextField(
                value = costStr,
                onValueChange = { costStr = it },
                label = { Text("سعر التكلفة ($currency)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                modifier = Modifier.weight(1f),
            )
            OutlinedTextField(
                value = lowStockStr,
                onValueChange = { lowStockStr = it },
                label = { Text("حد التنبيه") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                modifier = Modifier.weight(1f),
            )
        }

        HorizontalDivider()

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("وحدات البيع (${unitsList.size}/10)", style = MaterialTheme.typography.titleMedium)
            if (unitsList.size < 10) {
                TextButton(
                    onClick = {
                        unitsList.add(
                            ProductUnit(
                                unitName = if (trackingType == TrackingType.WEIGHT) "نصف كيلو" else "كرتونة",
                                unitType = if (trackingType == TrackingType.WEIGHT) UnitType.KG.name else UnitType.CARTON.name,
                                conversionFactor = if (trackingType == TrackingType.WEIGHT) 0.5 else 12.0,
                                price = 0.0,
                                allowDecimal = false,
                            )
                        )
                    }
                ) {
                    Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("إضافة وحدة")
                }
            }
        }

        // Quick Multi-Unit Presets
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            FilterChip(
                selected = false,
                onClick = {
                    val basePrice = unitsList.firstOrNull()?.price ?: 10.0
                    unitsList.clear()
                    unitsList.add(ProductUnit("قطعة", UnitType.PIECE.name, 1.0, basePrice, false, barcode))
                    unitsList.add(ProductUnit("كرتونة 12 قطعة", UnitType.CARTON.name, 12.0, basePrice * 11.5, false))
                    trackingType = TrackingType.COUNT
                    baseUnitName = "قطعة"
                },
                label = { Text("قالب: قطعة + كرتونة (12)") },
            )
            FilterChip(
                selected = false,
                onClick = {
                    val kiloPrice = unitsList.firstOrNull()?.price ?: 80.0
                    unitsList.clear()
                    unitsList.add(ProductUnit("كيلو", UnitType.KG.name, 1.0, kiloPrice, true, barcode))
                    unitsList.add(ProductUnit("نصف كيلو", UnitType.KG.name, 0.5, kiloPrice * 0.5, false))
                    unitsList.add(ProductUnit("ربع كيلو", UnitType.GRAM.name, 0.25, kiloPrice * 0.25, false))
                    trackingType = TrackingType.WEIGHT
                    baseUnitName = "كيلو"
                },
                label = { Text("قالب: كيلو + أنصاف + أرباع") },
            )
        }

        unitsList.forEachIndexed { idx, unit ->
            UnitEditorCard(
                index = idx,
                unit = unit,
                baseUnitName = baseUnitName,
                currency = currency,
                canDelete = unitsList.size > 1,
                onUnitChange = { updated -> unitsList[idx] = updated },
                onDelete = { unitsList.removeAt(idx) },
            )
        }

        if (validationError != null) {
            Text(
                text = validationError.orEmpty(),
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodySmall,
            )
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 6.dp, bottom = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            OutlinedButton(
                onClick = onDismiss,
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp),
            ) {
                Text("إلغاء")
            }
            Button(
                onClick = {
                    if (name.trim().isEmpty()) {
                        validationError = "يرجى إدخال اسم الصنف"
                        return@Button
                    }
                    if (baseUnitName.trim().isEmpty()) {
                        validationError = "يرجى إدخال اسم الوحدة الأساسية"
                        return@Button
                    }
                    val cleanedUnits = unitsList.filter { it.unitName.trim().isNotEmpty() }
                    if (cleanedUnits.isEmpty()) {
                        validationError = "يجب وجود وحدة بيع واحدة على الأقل"
                        return@Button
                    }
                    onSave(
                        initial.copy(
                            name = name.trim(),
                            barcode = barcode.trim(),
                            category = category.trim().ifEmpty { "عام" },
                            trackingType = trackingType.name,
                            baseUnitName = baseUnitName.trim(),
                            stockInBaseUnits = (stockStr.toDoubleOrNull() ?: 0.0).coerceAtLeast(0.0),
                            lowStockThreshold = (lowStockStr.toDoubleOrNull() ?: 5.0).coerceAtLeast(0.0),
                            costPrice = (costStr.toDoubleOrNull() ?: 0.0).coerceAtLeast(0.0),
                            units = cleanedUnits,
                        )
                    )
                },
                modifier = Modifier
                    .weight(1.4f)
                    .height(48.dp)
                    .testTag("save_product_button"),
            ) {
                Text("حفظ الصنف")
            }
        }
    }
}

@Composable
private fun UnitEditorCard(
    index: Int,
    unit: ProductUnit,
    baseUnitName: String,
    currency: String,
    canDelete: Boolean,
    onUnitChange: (ProductUnit) -> Unit,
    onDelete: () -> Unit,
) {
    var factorText by remember(index, unit.unitName) { mutableStateOf(formatQuantity(unit.conversionFactor)) }
    var priceText by remember(index, unit.unitName) { mutableStateOf(formatQuantity(unit.price)) }

    Surface(
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surfaceContainer,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("وحدة #${index + 1}", style = MaterialTheme.typography.titleSmall)
                if (canDelete) {
                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier.size(30.dp),
                    ) {
                        Icon(
                            Icons.Filled.DeleteOutline,
                            contentDescription = "حذف الوحدة",
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(18.dp),
                        )
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                OutlinedTextField(
                    value = unit.unitName,
                    onValueChange = { v ->
                        onUnitChange(
                            unit.copy(
                                unitName = v,
                                unitType = UnitType.detectFromName(v).name,
                            )
                        )
                    },
                    label = { Text("اسم الوحدة") },
                    singleLine = true,
                    modifier = Modifier.weight(1.2f),
                )
                OutlinedTextField(
                    value = factorText,
                    onValueChange = { v ->
                        factorText = v
                        val parsed = v.toDoubleOrNull()
                        if (parsed != null && parsed > 0.0) {
                            onUnitChange(unit.copy(conversionFactor = parsed))
                        }
                    },
                    label = { Text("المعامل ($baseUnitName)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.weight(1f),
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                OutlinedTextField(
                    value = priceText,
                    onValueChange = { v ->
                        priceText = v
                        val parsed = v.toDoubleOrNull()
                        if (parsed != null && parsed >= 0.0) {
                            onUnitChange(unit.copy(price = parsed))
                        }
                    },
                    label = { Text("سعر البيع ($currency)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.weight(1f),
                )
                Spacer(Modifier.width(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("كمية عشرية", style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.width(6.dp))
                    Switch(
                        checked = unit.allowDecimal,
                        onCheckedChange = { checked ->
                            onUnitChange(unit.copy(allowDecimal = checked))
                        },
                    )
                }
            }
        }
    }
}

