package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material.icons.outlined.Inventory2
import androidx.compose.material.icons.outlined.PointOfSale
import androidx.compose.material.icons.outlined.ReceiptLong
import androidx.compose.material.icons.outlined.UploadFile
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.data.firebase.PosRepository
import com.example.data.firebase.authStateFlow
import com.example.data.firebase.signOut
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.ImportScreen
import com.example.ui.screens.InventoryScreen
import com.example.ui.screens.InvoicesScreen
import com.example.ui.screens.PosScreen
import com.example.ui.screens.ReceiptDialog
import com.example.ui.screens.SettingsDialog
import com.example.ui.theme.CashierPlusTheme
import com.example.ui.viewmodel.CashierViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            CashierPlusTheme {
                AppContent()
            }
        }
    }
}

private enum class CashierTab(
    val route: String,
    val labelRes: Int,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
) {
    POS("pos", R.string.tab_pos, Icons.Filled.PointOfSale, Icons.Outlined.PointOfSale),
    INVENTORY("inventory", R.string.tab_inventory, Icons.Filled.Inventory2, Icons.Outlined.Inventory2),
    IMPORT("import", R.string.tab_import, Icons.Filled.UploadFile, Icons.Outlined.UploadFile),
    INVOICES("invoices", R.string.tab_invoices, Icons.Filled.ReceiptLong, Icons.Outlined.ReceiptLong),
}

@Composable
private fun AppContent() {
    val auth = Firebase.auth
    val currentUser by auth.authStateFlow().collectAsStateWithLifecycle(initialValue = auth.currentUser)
    val user = currentUser

    if (user == null) {
        AuthScreen(onAuthSuccess = {})
    } else {
        key(user.uid) {
            CashierHome(
                currentUserId = user.uid,
                userEmail = user.email,
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CashierHome(
    currentUserId: String,
    userEmail: String?,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }

    val viewModel: CashierViewModel = viewModel(
        key = currentUserId,
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY]) {
                    "APPLICATION_KEY missing from CreationExtras"
                }
                val databaseId = app.getString(R.string.firestore_database_id)
                val db = FirebaseFirestore.getInstance(databaseId)
                CashierViewModel(PosRepository(db), currentUserId)
            }
        }
    )

    val productsState by viewModel.productsState.collectAsStateWithLifecycle()
    val invoicesState by viewModel.invoicesState.collectAsStateWithLifecycle()
    val settings by viewModel.settingsState.collectAsStateWithLifecycle()
    val cartItems by viewModel.cartItems.collectAsStateWithLifecycle()
    val cartSummary by viewModel.cartSummary.collectAsStateWithLifecycle()
    val discountInput by viewModel.discountInput.collectAsStateWithLifecycle()
    val discountIsPercent by viewModel.discountIsPercent.collectAsStateWithLifecycle()
    val customerName by viewModel.customerName.collectAsStateWithLifecycle()
    val paymentMethod by viewModel.paymentMethod.collectAsStateWithLifecycle()
    val paidAmountInput by viewModel.paidAmountInput.collectAsStateWithLifecycle()
    val isCheckingOut by viewModel.isCheckingOut.collectAsStateWithLifecycle()
    val activeReceipt by viewModel.activeReceiptInvoice.collectAsStateWithLifecycle()
    val importState by viewModel.importState.collectAsStateWithLifecycle()
    val snackbarMessage by viewModel.snackbarMessage.collectAsStateWithLifecycle()

    var currentTab by remember { mutableStateOf(CashierTab.POS) }
    var showSettings by remember { mutableStateOf(false) }
    val snackbarHostState = remember { SnackbarHostState() }

    if (currentTab != CashierTab.POS) {
        BackHandler {
            currentTab = CashierTab.POS
        }
    }

    LaunchedEffect(snackbarMessage) {
        val msg = snackbarMessage
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            viewModel.consumeSnackbar()
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useNavRail = maxWidth >= 700.dp

        Scaffold(
            contentWindowInsets = WindowInsets.safeDrawing,
            snackbarHost = { SnackbarHost(snackbarHostState) },
            topBar = {
                TopAppBar(
                    title = {
                        Text(
                            text = settings.storeName.ifBlank { stringResource(R.string.app_name) },
                            style = MaterialTheme.typography.titleLarge,
                        )
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface,
                    ),
                    actions = {
                        IconButton(
                            onClick = { showSettings = true },
                            modifier = Modifier.testTag("open_settings_button"),
                        ) {
                            Icon(Icons.Filled.Settings, contentDescription = "إعدادات المتجر والحساب")
                        }
                    },
                )
            },
            bottomBar = {
                if (!useNavRail) {
                    NavigationBar {
                        CashierTab.entries.forEach { tab ->
                            val selected = currentTab == tab
                            NavigationBarItem(
                                selected = selected,
                                onClick = { currentTab = tab },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                        contentDescription = stringResource(tab.labelRes),
                                    )
                                },
                                label = { Text(stringResource(tab.labelRes)) },
                                modifier = Modifier.testTag("nav_tab_${tab.route}"),
                            )
                        }
                    }
                }
            },
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
            ) {
                if (useNavRail) {
                    NavigationRail(modifier = Modifier.fillMaxHeight()) {
                        CashierTab.entries.forEach { tab ->
                            val selected = currentTab == tab
                            NavigationRailItem(
                                selected = selected,
                                onClick = { currentTab = tab },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                        contentDescription = stringResource(tab.labelRes),
                                    )
                                },
                                label = { Text(stringResource(tab.labelRes)) },
                                modifier = Modifier.testTag("nav_rail_${tab.route}"),
                            )
                        }
                    }
                }

                Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                    when (currentTab) {
                        CashierTab.POS -> PosScreen(
                            productsState = productsState,
                            settings = settings,
                            cartItems = cartItems,
                            cartSummary = cartSummary,
                            discountInput = discountInput,
                            discountIsPercent = discountIsPercent,
                            customerName = customerName,
                            paymentMethod = paymentMethod,
                            paidAmountInput = paidAmountInput,
                            isCheckingOut = isCheckingOut,
                            onAddToCart = viewModel::addToCart,
                            onUpdateQuantity = viewModel::updateCartItemQuantity,
                            onSwitchUnit = viewModel::switchCartItemUnit,
                            onClearCart = viewModel::clearCart,
                            onDiscountChange = viewModel::setDiscountInput,
                            onDiscountPercentToggle = viewModel::setDiscountIsPercent,
                            onCustomerNameChange = viewModel::setCustomerName,
                            onPaymentMethodChange = viewModel::setPaymentMethod,
                            onPaidAmountChange = viewModel::setPaidAmountInput,
                            onCheckout = viewModel::completeCheckout,
                            onNavigateToImport = { currentTab = CashierTab.IMPORT },
                            onNavigateToInventory = { currentTab = CashierTab.INVENTORY },
                            onSeedSamples = viewModel::seedSampleCatalog,
                        )

                        CashierTab.INVENTORY -> InventoryScreen(
                            productsState = productsState,
                            settings = settings,
                            onSaveProduct = viewModel::saveProduct,
                            onDeleteProduct = viewModel::deleteProduct,
                            onNavigateToImport = { currentTab = CashierTab.IMPORT },
                        )

                        CashierTab.IMPORT -> ImportScreen(
                            importState = importState,
                            settings = settings,
                            onFilePicked = { uri -> viewModel.parseImportFile(context, uri) },
                            onToggleSelect = viewModel::toggleDraftSelection,
                            onSelectAll = viewModel::selectAllDrafts,
                            onUpdateDraft = viewModel::updateDraft,
                            onAddManualUnit = viewModel::addManualDraftUnit,
                            onUpdateTrackingType = viewModel::updateDraftTrackingType,
                            onClearDrafts = viewModel::clearImportDrafts,
                            onCommitImport = viewModel::commitImport,
                        )

                        CashierTab.INVOICES -> InvoicesScreen(
                            invoicesState = invoicesState,
                            productsState = productsState,
                            settings = settings,
                            onSelectInvoice = { inv -> viewModel.showReceipt(inv) },
                        )
                    }
                }
            }
        }
    }

    activeReceipt?.let { invoice ->
        ReceiptDialog(
            invoice = invoice,
            settings = settings,
            onDismiss = { viewModel.showReceipt(null) },
            onRefund = { inv -> viewModel.refundInvoice(inv) },
        )
    }

    if (showSettings) {
        SettingsDialog(
            settings = settings,
            userEmail = userEmail,
            onDismiss = { showSettings = false },
            onSave = { updated ->
                viewModel.saveSettings(updated) {
                    showSettings = false
                }
            },
            onSignOut = {
                showSettings = false
                signOut(credentialManager, scope)
            },
        )
    }
}
