package com.example.data.model

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp
import java.util.Locale

enum class TrackingType(val labelAr: String) {
    COUNT("بالعدد (قطعة / كرتونة)"),
    WEIGHT("بالوزن (كيلو / جرام)");

    companion object {
        fun fromRaw(raw: String?): TrackingType =
            entries.firstOrNull { it.name.equals(raw, ignoreCase = true) } ?: COUNT
    }
}

enum class UnitType(val labelAr: String, val defaultFactor: Double, val defaultDecimal: Boolean) {
    PIECE("قطعة", 1.0, false),
    PACK("علبة", 6.0, false),
    CARTON("كرتونة", 12.0, false),
    KG("كيلو", 1.0, true),
    GRAM("جرام", 0.001, false),
    CUSTOM("وحدة مخصصة", 1.0, false);

    companion object {
        fun fromRaw(raw: String?): UnitType =
            entries.firstOrNull { it.name.equals(raw, ignoreCase = true) } ?: PIECE

        fun detectFromName(unitName: String): UnitType {
            val normalized = unitName.trim().lowercase(Locale.ROOT)
            return when {
                normalized.contains("كرتون") || normalized.contains("شيكار") || normalized.contains("بالة") ||
                    normalized.contains("carton") || normalized.contains("box") || normalized.contains("case") -> CARTON
                normalized.contains("علب") || normalized.contains("باكت") || normalized.contains("دست") ||
                    normalized.contains("pack") || normalized.contains("dozen") -> PACK
                normalized == "جم" || normalized.contains("جرام") || normalized.contains("غرام") ||
                    normalized == "g" || normalized.contains("gram") -> GRAM
                normalized.contains("كيلو") || normalized.contains("كجم") || normalized.contains("وزن") ||
                    normalized == "kg" || normalized.contains("kilo") -> KG
                normalized.contains("قطع") || normalized.contains("حبة") || normalized.contains("فرد") ||
                    normalized.contains("piece") || normalized.contains("pcs") || normalized.contains("pc") -> PIECE
                else -> CUSTOM
            }
        }
    }
}

enum class PaymentMethod(val labelAr: String) {
    CASH("نقدي"),
    CARD("بطاقة"),
    TRANSFER("تحويل بنكي / محفظة");

    companion object {
        fun fromRaw(raw: String?): PaymentMethod =
            entries.firstOrNull { it.name.equals(raw, ignoreCase = true) } ?: CASH
    }
}

enum class InvoiceStatus(val labelAr: String) {
    COMPLETED("مكتملة"),
    REFUNDED("مرتجعة");

    companion object {
        fun fromRaw(raw: String?): InvoiceStatus =
            entries.firstOrNull { it.name.equals(raw, ignoreCase = true) } ?: COMPLETED
    }
}

@Keep
@IgnoreExtraProperties
data class ProductUnit(
    val unitName: String = "قطعة",
    val unitType: String = UnitType.PIECE.name,
    val conversionFactor: Double = 1.0,
    val price: Double = 0.0,
    val allowDecimal: Boolean = false,
    val barcode: String = "",
) {
    fun resolvedType(): UnitType = UnitType.fromRaw(unitType)

    fun toMap(): Map<String, Any> = mapOf(
        "unitName" to unitName.trim().ifEmpty { "قطعة" }.take(30),
        "unitType" to resolvedType().name,
        "conversionFactor" to conversionFactor.coerceAtLeast(0.0001),
        "price" to price.coerceAtLeast(0.0),
        "allowDecimal" to allowDecimal,
        "barcode" to barcode.trim().take(64),
    )
}

@Keep
@IgnoreExtraProperties
data class Product(
    @DocumentId val id: String = "",
    val userId: String = "",
    val name: String = "",
    val barcode: String = "",
    val category: String = "عام",
    val trackingType: String = TrackingType.COUNT.name,
    val baseUnitName: String = "قطعة",
    val stockInBaseUnits: Double = 0.0,
    val lowStockThreshold: Double = 5.0,
    val costPrice: Double = 0.0,
    val units: List<ProductUnit> = listOf(ProductUnit()),
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
) {
    fun resolvedTrackingType(): TrackingType = TrackingType.fromRaw(trackingType)

    fun primaryUnit(): ProductUnit = units.firstOrNull() ?: ProductUnit(unitName = baseUnitName)

    fun isLowStockFlag(): Boolean = stockInBaseUnits <= lowStockThreshold

    fun toCreateMap(ownerUid: String): Map<String, Any> {
        val safeUnits = (if (units.isEmpty()) listOf(ProductUnit(unitName = baseUnitName)) else units)
            .take(10)
            .map { it.toMap() }
        return mapOf(
            "userId" to ownerUid,
            "name" to name.trim().take(120),
            "barcode" to barcode.trim().take(64),
            "category" to category.trim().ifEmpty { "عام" }.take(60),
            "trackingType" to resolvedTrackingType().name,
            "baseUnitName" to baseUnitName.trim().ifEmpty { "قطعة" }.take(30),
            "stockInBaseUnits" to stockInBaseUnits.coerceAtLeast(0.0),
            "lowStockThreshold" to lowStockThreshold.coerceAtLeast(0.0),
            "costPrice" to costPrice.coerceAtLeast(0.0),
            "units" to safeUnits,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp(),
        )
    }

    fun toUpdateMap(): Map<String, Any> {
        val safeUnits = (if (units.isEmpty()) listOf(ProductUnit(unitName = baseUnitName)) else units)
            .take(10)
            .map { it.toMap() }
        return mapOf(
            "name" to name.trim().take(120),
            "barcode" to barcode.trim().take(64),
            "category" to category.trim().ifEmpty { "عام" }.take(60),
            "trackingType" to resolvedTrackingType().name,
            "baseUnitName" to baseUnitName.trim().ifEmpty { "قطعة" }.take(30),
            "stockInBaseUnits" to stockInBaseUnits.coerceAtLeast(0.0),
            "lowStockThreshold" to lowStockThreshold.coerceAtLeast(0.0),
            "costPrice" to costPrice.coerceAtLeast(0.0),
            "units" to safeUnits,
            "updatedAt" to FieldValue.serverTimestamp(),
        )
    }
}

@Keep
@IgnoreExtraProperties
data class InvoiceLineItem(
    val productId: String = "",
    val productName: String = "",
    val unitName: String = "قطعة",
    val unitType: String = UnitType.PIECE.name,
    val conversionFactor: Double = 1.0,
    val quantity: Double = 1.0,
    val unitPrice: Double = 0.0,
    val lineTotal: Double = 0.0,
) {
    fun toMap(): Map<String, Any> = mapOf(
        "productId" to productId,
        "productName" to productName.take(120),
        "unitName" to unitName.take(30),
        "unitType" to unitType,
        "conversionFactor" to conversionFactor.coerceAtLeast(0.0001),
        "quantity" to quantity.coerceAtLeast(0.001),
        "unitPrice" to unitPrice.coerceAtLeast(0.0),
        "lineTotal" to lineTotal.coerceAtLeast(0.0),
    )
}

@Keep
@IgnoreExtraProperties
data class Invoice(
    @DocumentId val id: String = "",
    val userId: String = "",
    val invoiceNumber: String = "",
    val customerName: String = "",
    val paymentMethod: String = PaymentMethod.CASH.name,
    val status: String = InvoiceStatus.COMPLETED.name,
    val items: List<InvoiceLineItem> = emptyList(),
    val subtotal: Double = 0.0,
    val discountAmount: Double = 0.0,
    val taxAmount: Double = 0.0,
    val totalAmount: Double = 0.0,
    val paidAmount: Double = 0.0,
    val changeAmount: Double = 0.0,
    val itemCount: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
) {
    fun resolvedPaymentMethod(): PaymentMethod = PaymentMethod.fromRaw(paymentMethod)
    fun resolvedStatus(): InvoiceStatus = InvoiceStatus.fromRaw(status)

    fun toCreateMap(ownerUid: String): Map<String, Any> {
        val safeItems = items.take(100).map { it.toMap() }
        return mapOf(
            "userId" to ownerUid,
            "invoiceNumber" to invoiceNumber.trim().take(40),
            "customerName" to customerName.trim().take(80),
            "paymentMethod" to resolvedPaymentMethod().name,
            "status" to InvoiceStatus.COMPLETED.name,
            "items" to safeItems,
            "subtotal" to subtotal.coerceAtLeast(0.0),
            "discountAmount" to discountAmount.coerceAtLeast(0.0),
            "taxAmount" to taxAmount.coerceAtLeast(0.0),
            "totalAmount" to totalAmount.coerceAtLeast(0.0),
            "paidAmount" to paidAmount.coerceAtLeast(0.0),
            "changeAmount" to changeAmount.coerceAtLeast(0.0),
            "itemCount" to safeItems.size.toLong().coerceIn(1L, 100L),
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp(),
        )
    }
}

@Keep
@IgnoreExtraProperties
data class StoreSettings(
    @DocumentId val id: String = "config",
    val userId: String = "",
    val storeName: String = "متجري",
    val currencySymbol: String = "ج.م",
    val taxRatePercent: Double = 0.0,
    val receiptFooter: String = "شكراً لتسوقكم معنا",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
) {
    fun toCreateMap(ownerUid: String): Map<String, Any> = mapOf(
        "userId" to ownerUid,
        "storeName" to storeName.trim().ifEmpty { "متجري" }.take(80),
        "currencySymbol" to currencySymbol.trim().ifEmpty { "ج.م" }.take(10),
        "taxRatePercent" to taxRatePercent.coerceIn(0.0, 100.0),
        "receiptFooter" to receiptFooter.trim().take(200),
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp(),
    )

    fun toUpdateMap(): Map<String, Any> = mapOf(
        "storeName" to storeName.trim().ifEmpty { "متجري" }.take(80),
        "currencySymbol" to currencySymbol.trim().ifEmpty { "ج.م" }.take(10),
        "taxRatePercent" to taxRatePercent.coerceIn(0.0, 100.0),
        "receiptFooter" to receiptFooter.trim().take(200),
        "updatedAt" to FieldValue.serverTimestamp(),
    )
}

data class CartItem(
    val key: String,
    val product: Product,
    val unit: ProductUnit,
    val quantity: Double,
) {
    val lineTotal: Double get() = quantity * unit.price
    val baseUnitsConsumed: Double get() = quantity * unit.conversionFactor
}

data class ImportedProductDraft(
    val localId: String,
    val name: String,
    val barcode: String,
    val category: String,
    val trackingType: TrackingType,
    val baseUnitName: String,
    val stockInBaseUnits: Double,
    val costPrice: Double,
    val units: List<ProductUnit>,
    val sourcePreview: String,
    val selected: Boolean = true,
)

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

fun formatMoney(amount: Double, currency: String): String {
    val formatted = if (amount % 1.0 == 0.0) {
        String.format(Locale.US, "%,.0f", amount)
    } else {
        String.format(Locale.US, "%,.2f", amount)
    }
    return "$formatted $currency"
}

fun formatQuantity(qty: Double): String {
    return if (qty % 1.0 == 0.0) {
        qty.toLong().toString()
    } else {
        String.format(Locale.US, "%.3f", qty).trimEnd('0').trimEnd('.')
    }
}
