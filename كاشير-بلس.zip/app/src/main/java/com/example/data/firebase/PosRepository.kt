package com.example.data.firebase

import android.content.Context
import com.example.R
import com.example.data.model.CartItem
import com.example.data.model.ImportedProductDraft
import com.example.data.model.Invoice
import com.example.data.model.InvoiceLineItem
import com.example.data.model.InvoiceStatus
import com.example.data.model.PaymentMethod
import com.example.data.model.Product
import com.example.data.model.ProductUnit
import com.example.data.model.StoreSettings
import com.example.data.model.TrackingType
import com.example.data.model.UnitType
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class PosRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth,
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private fun requireUserId(expectedUserId: String): String {
        val uid = auth.currentUser?.uid
            ?: throw IllegalStateException("يجب تسجيل الدخول أولاً قبل الوصول لبيانات المتجر.")
        check(uid == expectedUserId) { "تغير حساب المستخدم النشط؛ تم إلغاء العملية." }
        return uid
    }

    fun observeProducts(userId: String): Flow<List<Product>> = flow {
        val uid = requireUserId(userId)
        val path = "users/$uid/products"
        emitAll(
            db.collection("users").document(uid).collection("products")
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        Product::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == uid) {
                        handleFirestoreError(exceptionToLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    fun observeInvoices(userId: String): Flow<List<Invoice>> = flow {
        val uid = requireUserId(userId)
        val path = "users/$uid/invoices"
        emitAll(
            db.collection("users").document(uid).collection("invoices")
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        Invoice::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == uid) {
                        handleFirestoreError(exceptionToLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    fun observeStoreSettings(userId: String): Flow<StoreSettings> = flow {
        val uid = requireUserId(userId)
        val path = "users/$uid/storeSettings/config"
        emitAll(
            db.collection("users").document(uid)
                .collection("storeSettings").document("config")
                .snapshots()
                .map { snapshot ->
                    if (snapshot.exists()) {
                        snapshot.toObject(
                            StoreSettings::class.java,
                            DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                        ) ?: StoreSettings(userId = uid)
                    } else {
                        StoreSettings(userId = uid)
                    }
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == uid) {
                        handleFirestoreError(exceptionToLog, OperationType.GET, path)
                    }
                    throw error
                }
        )
    }

    suspend fun saveStoreSettings(userId: String, settings: StoreSettings): Result<Unit> {
        val docPath = "users/$userId/storeSettings/config"
        return try {
            val uid = requireUserId(userId)
            val docRef = db.collection("users").document(uid)
                .collection("storeSettings").document("config")
            val existingSnap = docRef.get().await()
            if (existingSnap.exists()) {
                docRef.update(settings.toUpdateMap()).await()
            } else {
                docRef.set(settings.toCreateMap(uid)).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docPath)
            Result.failure(e)
        }
    }

    suspend fun upsertProduct(userId: String, product: Product): Result<Unit> {
        var docPath = "users/$userId/products"
        return try {
            val uid = requireUserId(userId)
            require(product.name.trim().isNotEmpty()) { "اسم الصنف مطلوب" }
            require(product.baseUnitName.trim().isNotEmpty()) { "الوحدة الأساسية مطلوبة" }
            require(product.units.isNotEmpty()) { "يجب إضافة وحدة بيع واحدة على الأقل" }

            val colRef = db.collection("users").document(uid).collection("products")
            if (product.id.isBlank()) {
                val docRef = colRef.document()
                docPath = docRef.path
                docRef.set(product.toCreateMap(uid)).await()
            } else {
                val docRef = colRef.document(product.id)
                docPath = docRef.path
                docRef.update(product.toUpdateMap()).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docPath)
            Result.failure(e)
        }
    }

    suspend fun deleteProduct(userId: String, productId: String): Result<Unit> {
        val docPath = "users/$userId/products/$productId"
        return try {
            val uid = requireUserId(userId)
            require(productId.isNotBlank()) { "معرف الصنف غير صالح" }
            db.collection("users").document(uid)
                .collection("products").document(productId)
                .delete()
                .await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docPath)
            Result.failure(e)
        }
    }

    suspend fun importProductsBatch(
        userId: String,
        drafts: List<ImportedProductDraft>,
    ): Result<Int> {
        val path = "users/$userId/products"
        return try {
            val uid = requireUserId(userId)
            val selectedDrafts = drafts.filter { it.selected && it.name.trim().isNotEmpty() }
            if (selectedDrafts.isEmpty()) {
                return Result.failure(IllegalArgumentException("لا توجد أصناف محددة للاستيراد"))
            }

            val colRef = db.collection("users").document(uid).collection("products")
            selectedDrafts.chunked(400).forEach { chunk ->
                val batch = db.batch()
                chunk.forEach { draft ->
                    val product = Product(
                        userId = uid,
                        name = draft.name.trim().take(120),
                        barcode = draft.barcode.trim().take(64),
                        category = draft.category.trim().ifEmpty { "مستورد" }.take(60),
                        trackingType = draft.trackingType.name,
                        baseUnitName = draft.baseUnitName.trim().ifEmpty { "قطعة" }.take(30),
                        stockInBaseUnits = draft.stockInBaseUnits.coerceAtLeast(0.0),
                        lowStockThreshold = 5.0,
                        costPrice = draft.costPrice.coerceAtLeast(0.0),
                        units = draft.units.ifEmpty {
                            listOf(
                                ProductUnit(
                                    unitName = draft.baseUnitName.ifEmpty { "قطعة" },
                                    unitType = UnitType.detectFromName(draft.baseUnitName).name,
                                    conversionFactor = 1.0,
                                    price = 0.0,
                                    allowDecimal = draft.trackingType == TrackingType.WEIGHT,
                                    barcode = draft.barcode,
                                )
                            )
                        }.take(10),
                    )
                    val docRef = colRef.document()
                    batch.set(docRef, product.toCreateMap(uid))
                }
                batch.commit().await()
            }
            Result.success(selectedDrafts.size)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun checkoutSale(
        userId: String,
        cartItems: List<CartItem>,
        customerName: String,
        paymentMethod: PaymentMethod,
        discountAmount: Double,
        taxRatePercent: Double,
        paidAmount: Double,
        currentInvoiceCount: Int,
    ): Result<Invoice> {
        val path = "users/$userId/invoices"
        return try {
            val uid = requireUserId(userId)
            require(cartItems.isNotEmpty()) { "السلة فارغة" }
            val boundedCart = cartItems.take(100)

            val subtotal = boundedCart.sumOf { it.lineTotal }
            val safeDiscount = discountAmount.coerceIn(0.0, subtotal)
            val taxableAmount = (subtotal - safeDiscount).coerceAtLeast(0.0)
            val taxAmount = taxableAmount * (taxRatePercent.coerceIn(0.0, 100.0) / 100.0)
            val totalAmount = (taxableAmount + taxAmount).coerceAtLeast(0.0)
            val safePaid = paidAmount.coerceAtLeast(totalAmount)
            val changeAmount = (safePaid - totalAmount).coerceAtLeast(0.0)

            val dateStamp = SimpleDateFormat("yyMMdd", Locale.US).format(Date())
            val seq = String.format(Locale.US, "%04d", currentInvoiceCount + 1)
            val invoiceNumber = "INV-$dateStamp-$seq"

            val lineItems = boundedCart.map { item ->
                InvoiceLineItem(
                    productId = item.product.id,
                    productName = item.product.name,
                    unitName = item.unit.unitName,
                    unitType = item.unit.unitType,
                    conversionFactor = item.unit.conversionFactor,
                    quantity = item.quantity,
                    unitPrice = item.unit.price,
                    lineTotal = item.lineTotal,
                )
            }

            val invoiceCol = db.collection("users").document(uid).collection("invoices")
            val invoiceRef = invoiceCol.document()
            val invoice = Invoice(
                id = invoiceRef.id,
                userId = uid,
                invoiceNumber = invoiceNumber,
                customerName = customerName.trim().take(80),
                paymentMethod = paymentMethod.name,
                status = InvoiceStatus.COMPLETED.name,
                items = lineItems,
                subtotal = subtotal,
                discountAmount = safeDiscount,
                taxAmount = taxAmount,
                totalAmount = totalAmount,
                paidAmount = safePaid,
                changeAmount = changeAmount,
                itemCount = lineItems.size.toLong(),
                createdAt = Timestamp.now(),
                updatedAt = Timestamp.now(),
            )

            val batch = db.batch()
            batch.set(invoiceRef, invoice.toCreateMap(uid))

            val consumedByProductId = mutableMapOf<String, Pair<Double, Double>>()
            boundedCart.forEach { cartItem ->
                val pid = cartItem.product.id
                if (pid.isNotBlank()) {
                    val existingPair = consumedByProductId[pid]
                    val currentStock = existingPair?.first ?: cartItem.product.stockInBaseUnits
                    val totalConsumed = (existingPair?.second ?: 0.0) + cartItem.baseUnitsConsumed
                    consumedByProductId[pid] = currentStock to totalConsumed
                }
            }

            val productsCol = db.collection("users").document(uid).collection("products")
            consumedByProductId.forEach { (productId, stockPair) ->
                val newStock = (stockPair.first - stockPair.second).coerceAtLeast(0.0)
                batch.update(
                    productsCol.document(productId),
                    mapOf(
                        "stockInBaseUnits" to newStock,
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                )
            }

            batch.commit().await()
            Result.success(invoice)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun refundInvoice(
        userId: String,
        invoice: Invoice,
        currentProducts: List<Product>,
    ): Result<Unit> {
        val docPath = "users/$userId/invoices/${invoice.id}"
        return try {
            val uid = requireUserId(userId)
            require(invoice.id.isNotBlank()) { "رقم الفاتورة غير صالح" }
            require(invoice.resolvedStatus() == InvoiceStatus.COMPLETED) { "تم استرجاع هذه الفاتورة مسبقاً" }

            val batch = db.batch()
            val invoiceRef = db.collection("users").document(uid)
                .collection("invoices").document(invoice.id)
            batch.update(
                invoiceRef,
                mapOf(
                    "status" to InvoiceStatus.REFUNDED.name,
                    "updatedAt" to FieldValue.serverTimestamp(),
                )
            )

            val productsById = currentProducts.associateBy { it.id }
            val restoredByProductId = mutableMapOf<String, Double>()
            invoice.items.forEach { line ->
                if (line.productId.isNotBlank() && productsById.containsKey(line.productId)) {
                    val addBack = line.quantity * line.conversionFactor
                    restoredByProductId[line.productId] =
                        (restoredByProductId[line.productId] ?: 0.0) + addBack
                }
            }

            val productsCol = db.collection("users").document(uid).collection("products")
            restoredByProductId.forEach { (pid, addBack) ->
                val product = productsById[pid] ?: return@forEach
                val restoredStock = (product.stockInBaseUnits + addBack).coerceAtLeast(0.0)
                batch.update(
                    productsCol.document(pid),
                    mapOf(
                        "stockInBaseUnits" to restoredStock,
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                )
            }

            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun seedSampleCatalog(userId: String): Result<Unit> {
        val path = "users/$userId/products"
        return try {
            val uid = requireUserId(userId)
            val samples = listOf(
                Product(
                    userId = uid,
                    name = "أرز بسمتي هندي ذهبي",
                    barcode = "622100100101",
                    category = "حبوب وبقالة",
                    trackingType = TrackingType.WEIGHT.name,
                    baseUnitName = "كيلو",
                    stockInBaseUnits = 85.0,
                    lowStockThreshold = 10.0,
                    costPrice = 62.0,
                    units = listOf(
                        ProductUnit("كيلو", UnitType.KG.name, 1.0, 78.0, true, "622100100101"),
                        ProductUnit("نصف كيلو", UnitType.KG.name, 0.5, 40.0, false, ""),
                        ProductUnit("شيكارة 25 كيلو", UnitType.CARTON.name, 25.0, 1850.0, false, ""),
                    ),
                ),
                Product(
                    userId = uid,
                    name = "مياه معدنية طبيعية 600 مل",
                    barcode = "622100100202",
                    category = "مشروبات",
                    trackingType = TrackingType.COUNT.name,
                    baseUnitName = "قطعة",
                    stockInBaseUnits = 240.0,
                    lowStockThreshold = 24.0,
                    costPrice = 4.5,
                    units = listOf(
                        ProductUnit("قطعة", UnitType.PIECE.name, 1.0, 7.0, false, "622100100202"),
                        ProductUnit("شرنك 12 قطعة", UnitType.CARTON.name, 12.0, 75.0, false, ""),
                    ),
                ),
                Product(
                    userId = uid,
                    name = "بن عربي محوج فاخر",
                    barcode = "622100100303",
                    category = "قهوة وتوابل",
                    trackingType = TrackingType.WEIGHT.name,
                    baseUnitName = "كيلو",
                    stockInBaseUnits = 18.5,
                    lowStockThreshold = 3.0,
                    costPrice = 340.0,
                    units = listOf(
                        ProductUnit("كيلو", UnitType.KG.name, 1.0, 420.0, true, "622100100303"),
                        ProductUnit("ثمن كيلو (125 جم)", UnitType.GRAM.name, 0.125, 55.0, false, ""),
                        ProductUnit("جرام", UnitType.GRAM.name, 0.001, 0.45, false, ""),
                    ),
                ),
                Product(
                    userId = uid,
                    name = "شاي أسود ناعم 250 جم",
                    barcode = "622100100404",
                    category = "مشروبات ساخنة",
                    trackingType = TrackingType.COUNT.name,
                    baseUnitName = "علبة",
                    stockInBaseUnits = 96.0,
                    lowStockThreshold = 12.0,
                    costPrice = 45.0,
                    units = listOf(
                        ProductUnit("علبة", UnitType.PACK.name, 1.0, 58.0, false, "622100100404"),
                        ProductUnit("دستة 6 علب", UnitType.PACK.name, 6.0, 335.0, false, ""),
                        ProductUnit("كرتونة 24 علبة", UnitType.CARTON.name, 24.0, 1290.0, false, ""),
                    ),
                ),
            )
            val colRef = db.collection("users").document(uid).collection("products")
            val batch = db.batch()
            samples.forEach { item ->
                batch.set(colRef.document(), item.toCreateMap(uid))
            }
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }
}
