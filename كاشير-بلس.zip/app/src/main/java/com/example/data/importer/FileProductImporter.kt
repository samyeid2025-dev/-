package com.example.data.importer

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Xml
import com.example.data.model.ImportedProductDraft
import com.example.data.model.ProductUnit
import com.example.data.model.TrackingType
import com.example.data.model.UnitType
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import jxl.Workbook
import jxl.WorkbookSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayInputStream
import java.io.InputStream
import java.nio.charset.Charset
import java.util.Locale
import java.util.UUID
import java.util.zip.ZipInputStream

data class FileImportResult(
    val fileName: String,
    val fileTypeLabel: String,
    val drafts: List<ImportedProductDraft>,
    val rawLinesCount: Int,
)

object FileProductImporter {

    private var pdfBoxInitialized = false

    suspend fun parseUri(context: Context, uri: Uri): Result<FileImportResult> =
        withContext(Dispatchers.IO) {
            try {
                val appContext = context.applicationContext
                val fileName = resolveFileName(appContext, uri)
                val mime = appContext.contentResolver.getType(uri)?.lowercase(Locale.ROOT).orEmpty()
                val lowerName = fileName.lowercase(Locale.ROOT)

                val bytes = appContext.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                    ?: return@withContext Result.failure(IllegalStateException("تعذر فتح الملف المحدد"))

                if (bytes.isEmpty()) {
                    return@withContext Result.failure(IllegalArgumentException("الملف فارغ"))
                }

                val isPdf = lowerName.endsWith(".pdf") || mime.contains("pdf") ||
                    (bytes.size >= 4 && bytes[0] == '%'.code.toByte() && bytes[1] == 'P'.code.toByte() &&
                        bytes[2] == 'D'.code.toByte() && bytes[3] == 'F'.code.toByte())

                val isXlsx = lowerName.endsWith(".xlsx") ||
                    mime.contains("spreadsheetml") ||
                    (bytes.size >= 2 && bytes[0] == 'P'.code.toByte() && bytes[1] == 'K'.code.toByte())

                val isXls = lowerName.endsWith(".xls") || mime.contains("ms-excel")

                val result = when {
                    isPdf -> parsePdf(appContext, fileName, bytes)
                    isXlsx -> parseXlsx(fileName, bytes)
                    isXls -> parseXls(fileName, bytes)
                    else -> parseCsvOrText(fileName, bytes)
                }
                Result.success(result)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    private fun resolveFileName(context: Context, uri: Uri): String {
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (nameIdx >= 0 && cursor.moveToFirst()) {
                val name = cursor.getString(nameIdx)
                if (!name.isNullOrBlank()) return name
            }
        }
        return uri.lastPathSegment ?: "ملف_منتجات"
    }

    // --- PDF Parser using pdfbox-android ---
    private fun parsePdf(context: Context, fileName: String, bytes: ByteArray): FileImportResult {
        if (!pdfBoxInitialized) {
            PDFBoxResourceLoader.init(context)
            pdfBoxInitialized = true
        }
        val text = PDDocument.load(ByteArrayInputStream(bytes)).use { document ->
            val stripper = PDFTextStripper().apply {
                sortByPosition = true
            }
            stripper.getText(document)
        }
        val lines = text.lines()
            .map { normalizeDigits(it).trim() }
            .filter { it.isNotBlank() }

        val rows = mutableListOf<List<String>>()
        for (line in lines) {
            val splitCols = when {
                line.contains("|") -> line.split("|")
                line.contains("\t") -> line.split("\t")
                line.contains("  ") -> line.split(Regex("\\s{2,}"))
                else -> parseUnstructuredPdfLine(line)
            }.map { it.trim() }.filter { it.isNotEmpty() }

            if (splitCols.isNotEmpty()) {
                rows.add(splitCols)
            }
        }

        val drafts = mapTableRowsToDrafts(rows, isPdfFallback = true)
        return FileImportResult(
            fileName = fileName,
            fileTypeLabel = "PDF",
            drafts = drafts,
            rawLinesCount = lines.size,
        )
    }

    private fun parseUnstructuredPdfLine(line: String): List<String> {
        // Ignore pure headers/page numbers like "Page 1" or "صفحة 1"
        if (Regex("^(page|صفحة|تاريخ|date|total|الاجمالي|الإجمالي)\\b.*", RegexOption.IGNORE_CASE).matches(line)) {
            return emptyList()
        }
        // Try splitting trailing numeric tokens (price / stock) from product name
        val tokens = line.split(Regex("\\s+")).filter { it.isNotBlank() }
        if (tokens.size < 2) return emptyList()
        val numericValues = mutableListOf<String>()
        val textTokens = mutableListOf<String>()
        var detectedUnit: String? = null

        for (token in tokens) {
            val cleanNum = token.replace(",", "").replace("ج.م", "").replace("ر.س", "")
            val parsed = cleanNum.toDoubleOrNull()
            when {
                parsed != null -> {
                    // Long integer (>=8 digits) is likely a barcode
                    if (cleanNum.length >= 8 && !cleanNum.contains(".")) {
                        textTokens.add(token)
                    } else {
                        numericValues.add(cleanNum)
                    }
                }
                isUnitKeyword(token) && detectedUnit == null -> {
                    detectedUnit = token
                }
                else -> textTokens.add(token)
            }
        }
        if (textTokens.isEmpty() || numericValues.isEmpty()) return emptyList()

        val name = textTokens.joinToString(" ")
        val unit = detectedUnit ?: "قطعة"
        val price = numericValues.firstOrNull() ?: "0"
        val stock = if (numericValues.size > 1) numericValues.last() else "10"
        return listOf(name, unit, price, stock)
    }

    // --- XLSX OOXML Parser (Zip + XmlPullParser) ---
    internal fun parseXlsx(fileName: String, bytes: ByteArray): FileImportResult {
        val sharedStrings = mutableListOf<String>()
        val sheetBytesMap = linkedMapOf<String, ByteArray>()

        ZipInputStream(ByteArrayInputStream(bytes)).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                val name = entry.name
                if (!entry.isDirectory) {
                    if (name == "xl/sharedStrings.xml") {
                        sharedStrings.addAll(parseSharedStrings(zis.readBytes()))
                    } else if (name.startsWith("xl/worksheets/sheet") && name.endsWith(".xml")) {
                        sheetBytesMap[name] = zis.readBytes()
                    }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }

        val allRows = mutableListOf<List<String>>()
        sheetBytesMap.keys.sorted().forEach { sheetName ->
            val sheetBytes = sheetBytesMap[sheetName] ?: return@forEach
            allRows.addAll(parseWorksheetXml(sheetBytes, sharedStrings))
        }

        val drafts = mapTableRowsToDrafts(allRows, isPdfFallback = false)
        return FileImportResult(
            fileName = fileName,
            fileTypeLabel = "Excel (XLSX)",
            drafts = drafts,
            rawLinesCount = allRows.size,
        )
    }

    private fun parseSharedStrings(xmlBytes: ByteArray): List<String> {
        val strings = mutableListOf<String>()
        val parser = Xml.newPullParser()
        parser.setInput(ByteArrayInputStream(xmlBytes), "UTF-8")
        var insideSi = false
        var insideT = false
        val currentText = StringBuilder()

        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            when (event) {
                XmlPullParser.START_TAG -> {
                    when (parser.name) {
                        "si" -> {
                            insideSi = true
                            currentText.clear()
                        }
                        "t" -> if (insideSi) insideT = true
                    }
                }
                XmlPullParser.TEXT -> {
                    if (insideSi && insideT) {
                        currentText.append(parser.text ?: "")
                    }
                }
                XmlPullParser.END_TAG -> {
                    when (parser.name) {
                        "t" -> insideT = false
                        "si" -> {
                            insideSi = false
                            strings.add(currentText.toString())
                        }
                    }
                }
            }
            event = parser.next()
        }
        return strings
    }

    private fun parseWorksheetXml(
        xmlBytes: ByteArray,
        sharedStrings: List<String>,
    ): List<List<String>> {
        val rows = mutableListOf<List<String>>()
        val parser = Xml.newPullParser()
        parser.setInput(ByteArrayInputStream(xmlBytes), "UTF-8")

        var currentRow: MutableMap<Int, String>? = null
        var currentColIdx = 0
        var cellType = ""
        var insideValue = false
        var insideInlineText = false
        val cellBuffer = StringBuilder()

        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            when (event) {
                XmlPullParser.START_TAG -> {
                    when (parser.name) {
                        "row" -> currentRow = mutableMapOf()
                        "c" -> {
                            cellType = parser.getAttributeValue(null, "t") ?: ""
                            val ref = parser.getAttributeValue(null, "r")
                            currentColIdx = if (!ref.isNullOrBlank()) {
                                columnRefToIndex(ref)
                            } else {
                                (currentRow?.keys?.maxOrNull() ?: -1) + 1
                            }
                            cellBuffer.clear()
                        }
                        "v" -> insideValue = true
                        "t" -> insideInlineText = true
                    }
                }
                XmlPullParser.TEXT -> {
                    if (insideValue || insideInlineText) {
                        cellBuffer.append(parser.text ?: "")
                    }
                }
                XmlPullParser.END_TAG -> {
                    when (parser.name) {
                        "v" -> insideValue = false
                        "t" -> insideInlineText = false
                        "c" -> {
                            val raw = cellBuffer.toString().trim()
                            val resolved = when (cellType) {
                                "s" -> {
                                    val idx = raw.toIntOrNull()
                                    if (idx != null && idx in sharedStrings.indices) sharedStrings[idx] else ""
                                }
                                "b" -> if (raw == "1") "true" else "false"
                                else -> raw
                            }
                            if (resolved.isNotEmpty()) {
                                currentRow?.put(currentColIdx, normalizeDigits(resolved))
                            }
                        }
                        "row" -> {
                            val rowMap = currentRow
                            if (rowMap != null && rowMap.isNotEmpty()) {
                                val maxCol = rowMap.keys.maxOrNull() ?: 0
                                val rowList = (0..maxCol).map { idx -> rowMap[idx]?.trim().orEmpty() }
                                if (rowList.any { it.isNotEmpty() }) {
                                    rows.add(rowList)
                                }
                            }
                            currentRow = null
                        }
                    }
                }
            }
            event = parser.next()
        }
        return rows
    }

    private fun columnRefToIndex(ref: String): Int {
        var result = 0
        for (ch in ref) {
            if (ch in 'A'..'Z') {
                result = result * 26 + (ch - 'A' + 1)
            } else if (ch in 'a'..'z') {
                result = result * 26 + (ch - 'a' + 1)
            } else {
                break
            }
        }
        return (result - 1).coerceAtLeast(0)
    }

    // --- XLS Legacy Binary Parser (JExcelApi) ---
    internal fun parseXls(fileName: String, bytes: ByteArray): FileImportResult {
        val settings = WorkbookSettings().apply {
            encoding = "Cp1256"
        }
        val workbook = Workbook.getWorkbook(ByteArrayInputStream(bytes), settings)
        val rows = mutableListOf<List<String>>()
        try {
            workbook.sheets.forEach { sheet ->
                for (r in 0 until sheet.rows) {
                    val rowCells = (0 until sheet.columns).map { c ->
                        normalizeDigits(sheet.getCell(c, r).contents ?: "").trim()
                    }
                    if (rowCells.any { it.isNotEmpty() }) {
                        rows.add(rowCells)
                    }
                }
            }
        } finally {
            workbook.close()
        }
        val drafts = mapTableRowsToDrafts(rows, isPdfFallback = false)
        return FileImportResult(
            fileName = fileName,
            fileTypeLabel = "Excel (XLS)",
            drafts = drafts,
            rawLinesCount = rows.size,
        )
    }

    // --- CSV / TSV Parser with UTF-8 / Windows-1256 Support ---
    internal fun parseCsvOrText(fileName: String, bytes: ByteArray): FileImportResult {
        val text = decodeBestCharset(bytes).removePrefix("\uFEFF")
        val lines = text.lines().filter { it.isNotBlank() }
        val delimiter = detectDelimiter(lines.take(5))
        val rows = lines.map { line ->
            parseCsvLine(normalizeDigits(line), delimiter)
        }.filter { row -> row.any { it.isNotBlank() } }

        val drafts = mapTableRowsToDrafts(rows, isPdfFallback = false)
        return FileImportResult(
            fileName = fileName,
            fileTypeLabel = "CSV / Excel",
            drafts = drafts,
            rawLinesCount = rows.size,
        )
    }

    private fun decodeBestCharset(bytes: ByteArray): String {
        val utf8 = bytes.toString(Charsets.UTF_8)
        // If replacement char appears, fallback to Arabic Windows-1256
        return if (utf8.contains('\uFFFD')) {
            try {
                String(bytes, Charset.forName("windows-1256"))
            } catch (_: Exception) {
                utf8
            }
        } else {
            utf8
        }
    }

    private fun detectDelimiter(sampleLines: List<String>): Char {
        val joined = sampleLines.joinToString("\n")
        val tabs = joined.count { it == '\t' }
        val semis = joined.count { it == ';' }
        val commas = joined.count { it == ',' }
        return when {
            tabs >= semis && tabs >= commas && tabs > 0 -> '\t'
            semis > commas -> ';'
            else -> ','
        }
    }

    private fun parseCsvLine(line: String, delimiter: Char): List<String> {
        val cells = mutableListOf<String>()
        val current = StringBuilder()
        var inQuotes = false
        var i = 0
        while (i < line.length) {
            val ch = line[i]
            when {
                ch == '"' -> {
                    if (inQuotes && i + 1 < line.length && line[i + 1] == '"') {
                        current.append('"')
                        i++
                    } else {
                        inQuotes = !inQuotes
                    }
                }
                ch == delimiter && !inQuotes -> {
                    cells.add(current.toString().trim())
                    current.clear()
                }
                else -> current.append(ch)
            }
            i++
        }
        cells.add(current.toString().trim())
        return cells
    }

    // --- Smart Multi-Unit Table Mapper ---
    private data class ColumnMapping(
        val headerIndex: Int,
        val nameCol: Int,
        val barcodeCol: Int,
        val categoryCol: Int,
        val unitCol: Int,
        val priceCol: Int,
        val costCol: Int,
        val stockCol: Int,
        val cartonPriceCol: Int,
        val cartonFactorCol: Int,
    )

    private fun mapTableRowsToDrafts(
        rows: List<List<String>>,
        isPdfFallback: Boolean,
    ): List<ImportedProductDraft> {
        if (rows.isEmpty()) return emptyList()

        val mapping = detectHeaderMapping(rows)
        val dataRows = if (mapping != null) {
            rows.drop(mapping.headerIndex + 1)
        } else {
            rows
        }

        val groupedByProductKey = linkedMapOf<String, ImportedProductDraft>()

        dataRows.forEachIndexed { idx, row ->
            val cleanRow = row.map { it.trim() }
            if (cleanRow.all { it.isEmpty() }) return@forEachIndexed

            val rawName: String
            val rawBarcode: String
            val rawCategory: String
            val rawUnit: String
            val rawPrice: Double
            val rawCost: Double
            val rawStock: Double
            val rawCartonPrice: Double?
            val rawCartonFactor: Double

            if (mapping != null && mapping.nameCol >= 0) {
                rawName = cleanRow.getOrElse(mapping.nameCol) { "" }
                rawBarcode = if (mapping.barcodeCol >= 0) cleanRow.getOrElse(mapping.barcodeCol) { "" } else ""
                rawCategory = if (mapping.categoryCol >= 0) cleanRow.getOrElse(mapping.categoryCol) { "" } else ""
                rawUnit = if (mapping.unitCol >= 0) cleanRow.getOrElse(mapping.unitCol) { "" } else ""
                rawPrice = if (mapping.priceCol >= 0) parsePrice(cleanRow.getOrElse(mapping.priceCol) { "" }) ?: 0.0 else 0.0
                rawCost = if (mapping.costCol >= 0) parsePrice(cleanRow.getOrElse(mapping.costCol) { "" }) ?: 0.0 else 0.0
                rawStock = if (mapping.stockCol >= 0) parsePrice(cleanRow.getOrElse(mapping.stockCol) { "" }) ?: 10.0 else 10.0
                rawCartonPrice = if (mapping.cartonPriceCol >= 0) parsePrice(cleanRow.getOrElse(mapping.cartonPriceCol) { "" }) else null
                rawCartonFactor = if (mapping.cartonFactorCol >= 0) {
                    (parsePrice(cleanRow.getOrElse(mapping.cartonFactorCol) { "" }) ?: 12.0).coerceAtLeast(1.0)
                } else {
                    12.0
                }
            } else {
                // Headerless heuristic fallback (common in PDF price lists or simple 2-5 col sheets)
                val guessed = inferHeaderlessRow(cleanRow, isPdfFallback) ?: return@forEachIndexed
                rawName = guessed.name
                rawBarcode = guessed.barcode
                rawCategory = guessed.category
                rawUnit = guessed.unit
                rawPrice = guessed.price
                rawCost = 0.0
                rawStock = guessed.stock
                rawCartonPrice = null
                rawCartonFactor = 12.0
            }

            val finalName = rawName.trim()
            if (finalName.isEmpty() || finalName.all { it.isDigit() || it == '.' }) return@forEachIndexed
            if (finalName.equals("الإجمالي", true) || finalName.equals("المجموع", true) ||
                finalName.equals("total", true)
            ) {
                return@forEachIndexed
            }

            val unitName = rawUnit.ifBlank { "قطعة" }
            val detectedUnitType = UnitType.detectFromName(unitName)
            val isWeight = detectedUnitType == UnitType.KG || detectedUnitType == UnitType.GRAM ||
                finalName.contains("وزن") || finalName.contains("كيلو")

            val primaryUnit = ProductUnit(
                unitName = unitName,
                unitType = detectedUnitType.name,
                conversionFactor = 1.0,
                price = rawPrice,
                allowDecimal = detectedUnitType == UnitType.KG,
                barcode = rawBarcode,
            )

            val rowUnits = mutableListOf(primaryUnit)
            if (rawCartonPrice != null && rawCartonPrice > 0.0) {
                rowUnits.add(
                    ProductUnit(
                        unitName = "كرتونة (${rawCartonFactor.toInt()} $unitName)",
                        unitType = UnitType.CARTON.name,
                        conversionFactor = rawCartonFactor,
                        price = rawCartonPrice,
                        allowDecimal = false,
                        barcode = "",
                    )
                )
            } else if (detectedUnitType == UnitType.KG && rawPrice > 0.0) {
                // Convenient default gram unit when importing KG items without explicit second unit
                rowUnits.add(
                    ProductUnit(
                        unitName = "ربع كيلو (250 جم)",
                        unitType = UnitType.GRAM.name,
                        conversionFactor = 0.25,
                        price = (rawPrice * 0.25),
                        allowDecimal = false,
                        barcode = "",
                    )
                )
            }

            val mergeKey = finalName.lowercase(Locale.ROOT)
            val existing = groupedByProductKey[mergeKey]
            if (existing != null) {
                val mergedUnits = existing.units.toMutableList()
                rowUnits.forEach { candidate ->
                    if (mergedUnits.none { it.unitName.equals(candidate.unitName, ignoreCase = true) }) {
                        val factor = if (candidate.unitType == UnitType.CARTON.name && candidate.conversionFactor == 1.0) {
                            12.0
                        } else {
                            candidate.conversionFactor
                        }
                        mergedUnits.add(candidate.copy(conversionFactor = factor))
                    }
                }
                groupedByProductKey[mergeKey] = existing.copy(
                    units = mergedUnits.take(10),
                    stockInBaseUnits = maxOf(existing.stockInBaseUnits, rawStock),
                )
            } else {
                groupedByProductKey[mergeKey] = ImportedProductDraft(
                    localId = "draft_${idx}_${UUID.randomUUID().toString().take(6)}",
                    name = finalName.take(120),
                    barcode = rawBarcode.take(64),
                    category = rawCategory.ifBlank { "مستورد" }.take(60),
                    trackingType = if (isWeight) TrackingType.WEIGHT else TrackingType.COUNT,
                    baseUnitName = unitName.take(30),
                    stockInBaseUnits = rawStock.coerceAtLeast(0.0),
                    costPrice = rawCost.coerceAtLeast(0.0),
                    units = rowUnits,
                    sourcePreview = cleanRow.filter { it.isNotEmpty() }.joinToString(" | ").take(120),
                    selected = true,
                )
            }
        }

        return groupedByProductKey.values.toList()
    }

    private fun detectHeaderMapping(rows: List<List<String>>): ColumnMapping? {
        val searchLimit = minOf(rows.size, 8)
        for (rowIndex in 0 until searchLimit) {
            val row = rows[rowIndex].map { it.trim().lowercase(Locale.ROOT) }
            var nameCol = -1
            var barcodeCol = -1
            var categoryCol = -1
            var unitCol = -1
            var priceCol = -1
            var costCol = -1
            var stockCol = -1
            var cartonPriceCol = -1
            var cartonFactorCol = -1

            row.forEachIndexed { colIdx, cell ->
                if (cell.isEmpty()) return@forEachIndexed
                when {
                    nameCol < 0 && (cell.contains("اسم") || cell.contains("صنف") || cell.contains("منتج") ||
                        cell == "البيان" || cell.contains("product") || cell.contains("item") ||
                        cell == "name" || cell == "title") -> nameCol = colIdx

                    barcodeCol < 0 && (cell.contains("باركود") || cell.contains("كود") ||
                        cell.contains("barcode") || cell.contains("sku") || cell == "code") -> barcodeCol = colIdx

                    categoryCol < 0 && (cell.contains("فئة") || cell.contains("قسم") || cell.contains("تصنيف") ||
                        cell.contains("category") || cell.contains("group")) -> categoryCol = colIdx

                    cartonPriceCol < 0 && (((cell.contains("كرتون") || cell.contains("جمل") || cell.contains("شيكار") ||
                        cell.contains("carton") || cell.contains("box") || cell.contains("wholesale")) &&
                        (cell.contains("سعر") || cell.contains("price"))) || cell.contains("carton price")) -> cartonPriceCol = colIdx

                    cartonFactorCol < 0 && (cell.contains("معامل") || cell.contains("عبوة") || cell.contains("عدد القطع") ||
                        cell.contains("محتوى") || cell.contains("factor") || cell.contains("pack size")) -> cartonFactorCol = colIdx

                    unitCol < 0 && (cell.contains("وحد") || cell.contains("unit") || cell == "uom") -> unitCol = colIdx

                    costCol < 0 && (cell.contains("تكلف") || cell.contains("شراء") || cell.contains("cost")) -> costCol = colIdx

                    priceCol < 0 && (cell.contains("سعر") || cell.contains("price") || cell.contains("rate")) -> priceCol = colIdx

                    stockCol < 0 && (cell.contains("كمي") || cell.contains("مخزون") || cell.contains("رصيد") ||
                        cell.contains("qty") || cell.contains("quantity") || cell.contains("stock")) -> stockCol = colIdx
                }
            }

            if (nameCol >= 0 && (priceCol >= 0 || stockCol >= 0 || unitCol >= 0)) {
                return ColumnMapping(
                    headerIndex = rowIndex,
                    nameCol = nameCol,
                    barcodeCol = barcodeCol,
                    categoryCol = categoryCol,
                    unitCol = unitCol,
                    priceCol = priceCol,
                    costCol = costCol,
                    stockCol = stockCol,
                    cartonPriceCol = cartonPriceCol,
                    cartonFactorCol = cartonFactorCol,
                )
            }
        }
        return null
    }

    private data class GuessedRow(
        val name: String,
        val barcode: String,
        val category: String,
        val unit: String,
        val price: Double,
        val stock: Double,
    )

    private fun inferHeaderlessRow(cells: List<String>, isPdf: Boolean): GuessedRow? {
        val nonEmpty = cells.filter { it.isNotEmpty() }
        if (nonEmpty.isEmpty()) return null

        var barcode = ""
        var unit = ""
        val numbers = mutableListOf<Double>()
        val textParts = mutableListOf<String>()

        for (cell in nonEmpty) {
            val cleanedNum = cell.replace(",", "").replace("ج.م", "").replace("ر.س", "").trim()
            val asDouble = cleanedNum.toDoubleOrNull()
            when {
                asDouble != null && cleanedNum.length >= 8 && !cleanedNum.contains(".") -> {
                    if (barcode.isEmpty()) barcode = cleanedNum
                }
                asDouble != null -> numbers.add(asDouble)
                isUnitKeyword(cell) && unit.isEmpty() -> unit = cell
                else -> textParts.add(cell)
            }
        }

        val name = textParts.firstOrNull() ?: return null
        if (isPdf && numbers.isEmpty() && unit.isEmpty()) return null

        val category = if (textParts.size > 1) textParts[1] else "مستورد"
        val price = numbers.firstOrNull() ?: 0.0
        val stock = if (numbers.size > 1) numbers[1] else 10.0

        return GuessedRow(
            name = name,
            barcode = barcode,
            category = category,
            unit = unit.ifBlank { "قطعة" },
            price = price,
            stock = stock,
        )
    }

    private fun isUnitKeyword(token: String): Boolean {
        val lower = token.trim().lowercase(Locale.ROOT)
        val keywords = listOf(
            "قطعة", "قطع", "حبة", "كرتونة", "كرتون", "علبة", "باكت", "دستة",
            "كيلو", "كجم", "جم", "جرام", "غرام", "شيكارة", "لتر", "زجاجة",
            "piece", "pcs", "pc", "carton", "box", "pack", "kg", "g", "gram", "liter"
        )
        return keywords.any { lower == it || lower.contains(it) }
    }

    private fun parsePrice(raw: String): Double? {
        val normalized = normalizeDigits(raw)
            .replace(",", "")
            .replace(Regex("[^0-9.]"), "")
        return normalized.toDoubleOrNull()
    }

    private fun normalizeDigits(input: String): String {
        val arabicIndic = "٠١٢٣٤٥٦٧٨٩"
        val easternArabic = "۰۱۲۳۴۵۶۷۸۹"
        val sb = StringBuilder(input.length)
        for (ch in input) {
            val idx1 = arabicIndic.indexOf(ch)
            val idx2 = easternArabic.indexOf(ch)
            when {
                idx1 >= 0 -> sb.append(('0'.code + idx1).toChar())
                idx2 >= 0 -> sb.append(('0'.code + idx2).toChar())
                ch == '٫' -> sb.append('.')
                ch == '٬' -> sb.append(',')
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    fun buildSampleCsvTemplate(): String {
        return buildString {
            append('\uFEFF')
            appendLine("الاسم,الباركود,الفئة,الوحدة,السعر,التكلفة,الكمية,سعر الكرتونة,عدد القطع")
            appendLine("سكر أبيض ناعم,622100001001,بقالة,كيلو,38,31,120,,")
            appendLine("مياه غازية 330 مل,622100001002,مشروبات,قطعة,15,11,240,340,24")
            appendLine("زيت ذرة صافي 1 لتر,622100001003,زيوت,قطعة,95,82,60,1100,12")
            appendLine("جبنة رومي قديمة,622100001004,ألبان,كيلو,260,215,25,,")
            appendLine("مناديل وجه 550 منديل,622100001005,ورقيات,علبة,28,22,150,520,20")
        }
    }
}
